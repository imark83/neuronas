#include "fun.h"


void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	double l[8][order];

	for (i=0; i<order; i++) {
		dp_mulAD (i, l[0], series[0], series[0]);
		dp_mulAD (i, l[1], series[1], series[1]);
		dp_mulAD (i, l[2], series[0], series[1]);
			l[3][i] = 2*l[2][i];
		dp_sumAD (i, l[4], series[0], l[3]);
			l[5][i] = -l[4][i];
		dp_subAD (i, l[6], l[1], l[0]);
		dp_subAD (i, l[7], l[6], series[1]);


		series[0][i+1] = series[2][i]/(i+1.);
		series[1][i+1] = series[3][i]/(i+1.);
		series[2][i+1] = l[5][i]/(i+1.);
		series[3][i+1] = l[7][i]/(i+1.);
	
	}


}

void printFunctions (FILE *fout, double x[]) {
	fprintf (fout, "  %.16le", getEnergy (x));
}


double getEnergy (double x[]) {
	double K, V;
	K = (x[2]*x[2] + x[3]*x[3])/2.;
	V = (x[0]*x[0] + x[1]*x[1])/2. + x[0]*x[0]*x[1] - x[1]*x[1]*x[1]/3.;
	return K + V;


}

