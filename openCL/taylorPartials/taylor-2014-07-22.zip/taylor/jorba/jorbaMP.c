#include <stdio.h>
#include <mpfr.h>
#include <math.h>

#define u 1.11022302462516e-16

int digits = 30;

void getE (mpfr_t res, mpfr_t x[]); 

int main () {
	int precision = (int) ceil (digits * 3.321928);
	FILE *finp = fopen ("DPorbit18.txt", "r");
	FILE *fout = fopen ("jorbaTestMP.txt", "w");
	int i, j;
	double t, trash;
	mpfr_t x[4]; for (i=0; i<4; i++) mpfr_init2 (x[i],precision);
	mpfr_t dE; mpfr_init2 (dE, precision);
	mpfr_t E; mpfr_init2 (E, precision);
	mpfr_t E0; mpfr_init2 (E0, precision);
	mpfr_t uMP; mpfr_init2 (uMP, precision); mpfr_set_str (uMP, "1.11022302462516e-16", 10, GMP_RNDN);
	

	for (i=0; i<10001; i++) {
		fscanf (finp, "%le", &t);
		for (j=0; j<4; j++) mpfr_inp_str (x[j], finp, 10, GMP_RNDN);
		fscanf (finp, "%le", &trash);
		getE(E, x);
		mpfr_sub (dE, E, E0, GMP_RNDN);
		//j = (int) ceil (dE - 0.00001);
		mpfr_sub (dE, E, E0, GMP_RNDN); mpfr_div (dE, dE, uMP, GMP_RNDN);
		fprintf (fout, "%.8le  ", t); mpfr_out_str (fout, 10, 8, dE, GMP_RNDN); fprintf (fout, "\n");
		mpfr_set (E0, E, GMP_RNDN);
	}


	fclose (finp); fclose (fout);
}

void getE (mpfr_t res, mpfr_t x[4]) {
	int precision = (int) ceil (digits * 3.321928);
	mpfr_t aux; mpfr_init2 (aux, precision);
	mpfr_mul (res, x[3], x[3], GMP_RNDN);
	mpfr_mul (aux, x[1], x[1], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_mul (aux, x[2], x[2], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_mul (aux, x[0], x[0], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_div_si (res, res, 2, GMP_RNDN);
	mpfr_mul (aux, aux, x[1], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_pow_ui (aux, x[1], 3, GMP_RNDN);
	mpfr_div_si (aux, aux, 3, GMP_RNDN);
	mpfr_sub (res, res, aux, GMP_RNDN);



}
