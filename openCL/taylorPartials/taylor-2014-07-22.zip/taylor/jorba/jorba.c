#include <stdio.h>
#include <mpfr.h>
#include <math.h>

#define u 1.11022302462516e-16

int digits = 30;

double getE (mpfr_t x[]); 

int main () {
	int precision = (int) ceil (digits * 3.321928);
	FILE *finp = fopen ("DPorbit18.txt", "r");
	FILE *fout = fopen ("jorbaTest.txt", "w");
	int i, j;
	double t, dE, E, E0=0.125, trash;
	mpfr_t x[4]; for (i=0; i<4; i++) mpfr_init2 (x[i],precision);

	for (i=0; i<10001; i++) {
		fscanf (finp, "%le", &t);
		for (j=0; j<4; j++) mpfr_inp_str (x[j], finp, 10, GMP_RNDN);
		fscanf (finp, "%le", &trash);
		E = getE(x);
		dE = (E-E0);
		dE = (E-E0)/u;
		//j = (int) ceil (dE - 0.00001);
		if (dE<0) dE = floor (dE);
		if (dE>0) dE = ceil (dE);
		fprintf (fout, "%.8le, %i\n", t, (int) dE);
		E0 = E;
	}


	fclose (finp); fclose (fout);
}

double getE (mpfr_t x[4]) {
	int precision = (int) ceil (digits * 3.321928);
	mpfr_t aux; mpfr_init2 (aux, precision);
	mpfr_t res; mpfr_init2 (res, precision);
	mpfr_mul (res, x[3], x[3], GMP_RNDN);
	mpfr_mul (aux, x[1], x[1], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_mul (aux, x[2], x[2], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_mul (aux, x[0], x[0], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_div_si (res, res, 2, GMP_RNDN);
	mpfr_mul (aux, aux, x[1], GMP_RNDN);
	mpfr_add (res, res, aux, GMP_RNDN);
	mpfr_pow_ui (aux, x[1], 3, GMP_RNDN);
	mpfr_div_si (aux, aux, 3, GMP_RNDN);
	mpfr_sub (res, res, aux, GMP_RNDN);

	return mpfr_get_d (res, GMP_RNDN);


}
