#ifndef _taylor_h
#define _taylor_h
#include <stdio.h>
#include <math.h>
#include "fun.h"

void taylor (int nvar, double x[nvar], double t0, double delta, int nt, double tol, FILE *fout);
void poincare (int nvar, int order, double h, double series[nvar][order+1], int event, 
		double rop[nvar], double *tCut);
int getOrder (double tol);
double getStep (int nvar, int order, double series[nvar][order+1],
		double tol);
void horner (int nvar, int order, double h, double series[nvar][order+1],
		double rop[nvar]);
double normInf (int nvar, double x[nvar]);

#endif
