#include "funMP.h"

mpfr_t s, r, b;

void mp_fun (int nvar, int order, mpfr_t t, mpfr_t x[nvar], 
		mpfr_t series[nvar][order+1]) {
	int i, j;
	static int unavez = 1;
	if (unavez) {
		mpfr_init (s); mpfr_init (r); mpfr_init (b);
		mpfr_set_str (s, "10", 10, GMP_RNDN);
		mpfr_set_str (r, "28", 10, GMP_RNDN);
		mpfr_set_si (b, -8, GMP_RNDN); mpfr_div_si (b, b, 3, GMP_RNDN);
	}
	unavez = 0;
	for (i=0; i<nvar; i++) mpfr_set (series[i][0], x[i], GMP_RNDN);



	int nlink = 11;
	mpfr_t l[nlink][order], lAux[order];
	for (i=0; i<nlink; i++) for (j=0; j<order; j++) mpfr_init (l[i][j]);
	for (j=0; j<order; j++) mpfr_init (lAux[j]);

	for (i=0; i<order; i++) {
		if (i==0) mpfr_add_si(lAux[0], series[2][0], 27, GMP_RNDN); //cambios
		else mpfr_set (lAux[i], series[2][i], GMP_RNDN); //cambios
		mpfr_mul_si (l[0][i], series[0][i], -1, GMP_RNDN);
		mp_sumAD (i, l[1], series[1], l[0]);
		mpfr_mul (l[2][i], l[1][i], s, GMP_RNDN);
		mp_mulAD(i, l[3], l[0], lAux); // cambiado
		mpfr_mul (l[4][i], series[0][i], r, GMP_RNDN);
		mpfr_mul_si (l[5][i], series[1][i], -1, GMP_RNDN);
		mp_sumAD (i, l[6], l[3], l[4]);
		mp_sumAD (i, l[7], l[6], l[5]);

		mp_mulAD (i, l[8], series[0], series[1]);
		mpfr_mul (l[9][i], lAux[i], b, GMP_RNDN); //cambiado
		mp_sumAD (i, l[10], l[8], l[9]);


		mpfr_div_si (series[0][i+1], l[2][i], i+1, GMP_RNDN);
		mpfr_div_si (series[1][i+1], l[7][i], i+1, GMP_RNDN);
		mpfr_div_si (series[2][i+1], l[10][i], i+1, GMP_RNDN);
	}

	for (i=0; i<nlink; i++) for (j=0; j<order; j++) mpfr_clear (l[i][j]);
	for (j=0; j<order; j++) mpfr_clear (lAux[j]);

}

void printFunctions (FILE *fout, mpfr_t x[], int digits) {
}



