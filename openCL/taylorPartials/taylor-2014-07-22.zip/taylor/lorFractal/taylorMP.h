#ifndef _taylor_h
#define _taylor_h
#include <stdio.h>
#include <math.h>
#include "funMP.h"
#include <mpfr.h>

void mp_taylor (int nvar, mpfr_t x[nvar], mpfr_t t0, mpfr_t delta, int nt, 
		mpfr_t tol, FILE *fout);
void poincare (int nvar, int order, mpfr_t step, mpfr_t series[nvar][order+1], int event, mpfr_t rop[nvar]);
void mp_taylor_old (int nvar, mpfr_t x[nvar], int nlt, mpfr_t lt[nlt], mpfr_t tol, FILE *fout);
int getOrder (mpfr_t tol);
void getStep (mpfr_t rop, int nvar, int order, mpfr_t series[nvar][order+1],
		mpfr_t tol);
void horner (int nvar, int order, mpfr_t h, mpfr_t series[nvar][order+1],
		mpfr_t rop[nvar]);
void normInf (mpfr_t rop, int nvar, mpfr_t x[nvar]);

#endif
