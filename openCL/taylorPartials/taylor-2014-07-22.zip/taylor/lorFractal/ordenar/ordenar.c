#include <stdio.h>


int main () {
	FILE *finp = fopen ("aux.txt", "r");
	FILE *fout = fopen ("orderedAux.txt", "w");
	
	int size = 26611, i, j;

	double x[size][3], aux;

	for (i=0; i<size; i++) {
		fscanf (finp, " %le %le %le\n", &x[i][0], &x[i][1], &x[i][2]);
	}

	for (i=2; i<=size; i++) {
		for (j=0; j<=size-i; j++) {
			if (x[j][0] > x[j+1][0]) {
				aux = x[j][0];
				x[j][0] = x[j+1][0];
				x[j+1][0] = aux;
				aux = x[j][1];
				x[j][1] = x[j+1][1];
				x[j+1][1] = aux;
				aux = x[j][2];
				x[j][2] = x[j+1][2];
				x[j+1][2] = aux;
			}
		}
	}
	for (i=0; i<size; i++) {
		fprintf  (fout, " %.16le %.16le %.16le\n", x[i][0], x[i][1], x[i][2]);
	}

}
