#include <stdio.h>


int main () {
	FILE *fout = fopen ("auxShort.txt", "w");
	FILE *finp = fopen ("orderedAux.txt", "r");
	
	int size = 26611, i, j;

	double x[size][3], aux;

	for (i=0; i<size; i++) {
		fscanf (finp, " %le %le %le\n", &x[i][0], &x[i][1], &x[i][2]);
		if (x[i][0]>14 && x[i][0] < 14.5)
			fprintf  (fout, " %.16le %.16le %.16le\n", x[i][0], x[i][1], x[i][2]);
	}

}
