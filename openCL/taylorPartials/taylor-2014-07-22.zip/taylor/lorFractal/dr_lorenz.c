#include "taylorMP.h"
#include <stdlib.h>
int fac = 1;
int digits = 16;
FILE *fpoinc;
int event = 2;

double getRand ();

int main () {
        srand (time (NULL)*getpid());
	int nvar = 3;
	int i, j, nt, precision = (int) ceil (digits * 3.321928);
	mpfr_t x[nvar]; 
		for (i=0; i<nvar; i++) {
			mpfr_init2 (x[i], precision);

		}
	mpfr_t t0, delta, tol, dx, dy, dz; 
	mpfr_init2 (tol, precision);
	mpfr_init2 (delta, precision);
	mpfr_init2 (dx, precision);
	mpfr_init2 (dy, precision);
	mpfr_init2 (dz, precision);


	
	mpfr_set_si (t0, 0, GMP_RNDN);
	nt = 2;
	mpfr_set_str (delta, "5000", 10, GMP_RNDN);

	FILE *fout;
	fout = fopen ("out.txt", "w");

/*	FILE *ftemp = fopen ("source.txt", "w");
	for (i=0; i<100; i++) {
		mpfr_set_str (dx, "1e-3", 10, GMP_RNDN);
			mpfr_mul_d (dx, dx, getRand(), GMP_RNDN);	
		mpfr_set_str (dy, "1e-3", 10, GMP_RNDN);
			mpfr_mul_d (dy, dy, getRand(), GMP_RNDN);	
		mpfr_set_str (dz, "1e-3", 10, GMP_RNDN);
			mpfr_mul_d (dz, dz, getRand(), GMP_RNDN);
	
		mpfr_set_str (x[0], "1.1719484240776200e+01", 10, GMP_RNDN);
			mpfr_add (x[0], x[0], dx, GMP_RNDN);
		mpfr_set_str (x[1], "1.5061669834561609e+01", 10, GMP_RNDN);
			mpfr_add (x[1], x[1], dy, GMP_RNDN);
		mpfr_set_str (x[2], "-1e-1", 10, GMP_RNDN);
		//	mpfr_add (x[2], x[2], dz, GMP_RNDN);
		mpfr_out_str (ftemp, 10, digits, x[0], GMP_RNDN); fprintf (ftemp, " ");
		mpfr_out_str (ftemp, 10, digits, x[1], GMP_RNDN); fprintf (ftemp, " ");
		mpfr_out_str (ftemp, 10, digits, x[2], GMP_RNDN); fprintf (ftemp, "\n");
	}
	fclose (ftemp);*/
for (j=0; j<200; j++) {	
	fpoinc = fopen ("aux.txt", "w");
	FILE *finp = fopen ("source.txt", "r");
	for (i=0; i<100; i++) {
		mpfr_inp_str (x[0], finp, 10, GMP_RNDN); fscanf (finp, " ");
		mpfr_inp_str (x[1], finp, 10, GMP_RNDN); fscanf (finp, " ");
		mpfr_inp_str (x[2], finp, 10, GMP_RNDN); fscanf (finp, "\n");
		mpfr_set_str (x[2], "-1e-1", 10, GMP_RNDN);
		mpfr_set_str (tol, "1e-16", 10, GMP_RNDN);
		mp_taylor (nvar, x, t0, delta, nt, tol, fout);
	}
	fclose (fpoinc);
	fclose (finp);
	rename ("aux.txt","source.txt");

}
	return 0;

}



double getRand () {
        return rand ()/((float) RAND_MAX)*2. - 1.;

}

