#ifndef _taylorMPAD_h
#define _taylorMPAD_h
#include <stdio.h>
#include <mpfr.h>
#include <math.h>

extern int MAX_ORDER;
extern int NDER;

/************************************************************************/
void htilde (int n, int i, mpfr_t ht, mpfr_t h[NDER+1][MAX_ORDER+1], int j, int v);
/************************************************************************/

void mp_sumAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1],  mpfr_t op1[NDER+1][MAX_ORDER+1], 
		mpfr_t op2[NDER+1][MAX_ORDER+1]);
void mp_smCAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2);
void mp_sbCAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2);
void mp_subAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1],  mpfr_t op1[NDER+1][MAX_ORDER+1], 
		mpfr_t op2[NDER+1][MAX_ORDER+1]);
void mp_mulAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2[NDER+1][MAX_ORDER+1]);
void mp_mlCAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1], 
		mpfr_t op2);
void mp_divAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2[NDER+1][MAX_ORDER+1]);
void mp_powAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2);


#endif
