#ifndef _funMP_h
#define _funMP_h
#include <stdio.h>
#include <mpfr.h>
#include "taylorMPAD.h"

int getNCols ();
void mp_fun (int ncol, int order, mpfr_t t, mpfr_t x[ncol], 
		mpfr_t series[ncol][order+1]);
void mp_funBack (int ncol, int order, mpfr_t t, mpfr_t x[ncol], 
		mpfr_t series[ncol][order+1]);
void printFunctions (FILE *fout, mpfr_t x[], int digits);
void getEnergy (mpfr_t E, mpfr_t x[]);

#endif
