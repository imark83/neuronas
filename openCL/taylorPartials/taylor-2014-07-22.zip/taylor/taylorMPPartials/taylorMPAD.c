#include "taylorMPAD.h"


int  *PREV_ACCUM;
int  *PREV_COEF;
int  *PREV_VI;
int  *PREV_IV;

int  *PREVSTAR_ACCUM;
int  *PREVSTAR_COEF;
int  *PREVSTAR_VI;
int  *PREVSTAR_IV;



/************************************************************************/
void htilde (int n, int i, mpfr_t ht, mpfr_t h[NDER+1][MAX_ORDER+1], int j, int v) {
	if (j == n && i==v) mpfr_set_si (ht, 0, MPFR_RNDN);
	else mpfr_set (ht, h[v][j], MPFR_RNDN);
}
/************************************************************************/

void derInit (int *p_a, int *p_c, int *p_vi, int *p_iv, int *ps_a, int *ps_c, int *ps_vi, int *ps_iv) {
	PREV_ACCUM = p_a;
	PREV_COEF = p_c;
	PREV_VI = p_vi;
	PREV_IV = p_iv;
	PREVSTAR_ACCUM = ps_a;
	PREVSTAR_COEF = ps_c;
	PREVSTAR_VI = ps_vi;
	PREVSTAR_IV = ps_iv;
}


void mp_sumAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1],  mpfr_t op1[NDER+1][MAX_ORDER+1], 
		mpfr_t op2[NDER+1][MAX_ORDER+1]) {
	int i;
	for(i = 0; i <= NDER; i++) 
		mpfr_add (rop[i][order], op1[i][order], op2[i][order], MPFR_RNDN);
}

void mp_smCAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2) {
	int i;
	if (order == 0) 
		mpfr_add (rop[0][0], op1[0][0], op2, MPFR_RNDN);
	else  
		mpfr_set (rop[0][order], op1[0][order], MPFR_RNDN);
	for (i=1; i <= NDER; i++) 
		mpfr_set (rop[i][order], op1[i][order], MPFR_RNDN);
}

void mp_sbCAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2) {
	int i;
	if (order == 0) 
		mpfr_sub (rop[0][0], op1[0][0], op2, MPFR_RNDN);
	else  
		mpfr_set (rop[0][order], op1[0][order], MPFR_RNDN);
	for (i=1; i <= NDER; i++) 
		mpfr_set (rop[i][order], op1[i][order], MPFR_RNDN);
}


void mp_subAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1], 
		mpfr_t op2[NDER+1][MAX_ORDER+1]) {
	int i;
	for(i = 0; i <= NDER; i++) 
		mpfr_sub (rop[i][order], op1[i][order], op2[i][order], MPFR_RNDN);
}

void mp_mulAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2[NDER+1][MAX_ORDER+1]) {
	int i, vi, j;
	mpfr_t sumint, aux;
	mpfr_inits (sumint, aux, (mpfr_ptr) 0);

	for(i=0; i<=NDER; i++) {
		mpfr_set_si (rop[i][order], 0, MPFR_RNDN);
		for(vi=PREV_ACCUM[i]; vi<PREV_ACCUM[i+1]; vi++) {
			mpfr_set_si (sumint, 0, MPFR_RNDN);
			for(j=0; j<=order; j++) {
				mpfr_mul (aux, op1[PREV_VI[vi]][order-j], op2[PREV_IV[vi]][j], MPFR_RNDN);
				mpfr_add (sumint, sumint, aux, MPFR_RNDN);
			}
			mpfr_mul_si (aux, sumint, PREV_COEF[vi], MPFR_RNDN);
			mpfr_add (rop[i][order], rop[i][order], aux, MPFR_RNDN);
		}
	}
	mpfr_clears (sumint, aux, (mpfr_ptr) 0);
}

void mp_mlCAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1], 
		mpfr_t op2) {
	int i;
	for(i=0; i<=NDER; i++) 
		mpfr_mul (rop[i][order], op1[i][order], op2, MPFR_RNDN);	
}

void mp_divAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2[NDER+1][MAX_ORDER+1]) {

	if (mpfr_sgn (op2[0][0]) == 0) {printf ("Error, divide by 0, bad result\n"); return;}

	int i, j, vi;
	mpfr_t sumint, ht, aux;
	mpfr_inits (sumint, ht, aux, (mpfr_ptr) 0);

	for (i=0; i<=NDER; i++) {
		mpfr_set_si (rop[i][order], 0, MPFR_RNDN);
		for(vi=PREV_ACCUM[i]; vi<PREV_ACCUM[i+1]; vi++) {
			mpfr_set_si (sumint, 0, MPFR_RNDN);
			for (j=0; j<=order; j++) {
				htilde (order, i, ht, rop, order-j, PREV_VI[vi]);
				mpfr_mul (aux, ht, op2[PREV_IV[vi]][j], MPFR_RNDN);
				mpfr_add (sumint, sumint, aux, MPFR_RNDN);
			}
			mpfr_mul_si (aux, sumint, PREV_COEF[vi], MPFR_RNDN);
			mpfr_add (rop[i][order], rop[i][order], aux, MPFR_RNDN);
		}
		mpfr_sub (rop[i][order], op1[i][order], rop[i][order], MPFR_RNDN);
		mpfr_div (rop[i][order], rop[i][order], op2[0][0], MPFR_RNDN);

	}
	mpfr_clears (sumint, ht, aux, (mpfr_ptr) 0);
}

void mp_powAD (int order, mpfr_t rop[NDER+1][MAX_ORDER+1], mpfr_t op1[NDER+1][MAX_ORDER+1],
		mpfr_t op2) {

	if (mpfr_sgn(op1[0][0]) == 0.) {printf ("Error, divide by 0, bad result\n"); return;}
	mpfr_t ht, aux, aux2;
	mpfr_inits (ht, aux, aux2, (mpfr_ptr) 0);
	int i, j, vi;

	if (order == 0) {			
		mpfr_pow (rop[0][0], op1[0][0], op2, MPFR_RNDN);
		for (i=1; i<=NDER; i++) {
			mpfr_set_si (rop[i][0], 0, MPFR_RNDN);
			for (vi=PREVSTAR_ACCUM[i]; vi<PREVSTAR_ACCUM[i+1]; vi++) {
				htilde (0, i, ht, rop, 0, PREVSTAR_IV[vi]);
				mpfr_mul (aux, ht, op1[PREVSTAR_VI[vi]][0], MPFR_RNDN);
				mpfr_mul (aux2, rop[PREVSTAR_VI[vi]][0], op1[PREVSTAR_IV[vi]][0], MPFR_RNDN);
				mpfr_mul (aux2, aux2, op2, MPFR_RNDN);
				mpfr_sub (aux, aux2, aux, MPFR_RNDN);
				mpfr_mul_si (aux, aux, PREVSTAR_COEF[vi], MPFR_RNDN);

				mpfr_add (rop[i][0], rop[i][0], aux, MPFR_RNDN);
			}
			mpfr_div (rop[i][0], rop[i][0], op1[0][0], MPFR_RNDN);
		}
	}
	else {
		mpfr_t sumint;
		mpfr_init (sumint);
		for (i=0; i<=NDER; i++) {
			mpfr_set_si (rop[i][order], 0, MPFR_RNDN);
			for (j=0; j<=order; j++) {
				mpfr_set_si (sumint, 0, MPFR_RNDN);
				for (vi=PREV_ACCUM[i]; vi<PREV_ACCUM[i+1]; vi++) {
					htilde (order, i, ht, rop, j, PREV_VI[vi]);
					mpfr_mul (aux, ht, op1[PREV_IV[vi]][order-j], MPFR_RNDN);
					mpfr_mul_si (aux, aux, PREV_COEF[vi], MPFR_RNDN);
					mpfr_add (sumint, sumint, aux, MPFR_RNDN);
				}
				mpfr_add_si (aux, op2, 1, MPFR_RNDN);
				mpfr_mul_si (aux, aux, j, MPFR_RNDN);
				mpfr_mul_si (aux2, op2, order, MPFR_RNDN);
				mpfr_sub (aux, aux2, aux, MPFR_RNDN);
				mpfr_mul (aux, aux, sumint, MPFR_RNDN);
				mpfr_add (rop[i][order], rop[i][order], aux, MPFR_RNDN);
			}
			mpfr_div (rop[i][order], rop[i][order], op1[0][0], MPFR_RNDN);
			mpfr_div_si (rop[i][order], rop[i][order], order, MPFR_RNDN);
		}
		mpfr_clear (sumint);
	}
	mpfr_clears (ht, aux, aux2, (mpfr_ptr) 0);
}

