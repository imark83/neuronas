#include <stdio.h>
#include <mpfr.h>
#include "taylorMP.h"


mpfr_t mu; // = 0.012277471;
mpfr_t unomenosmu; // = 0.987722529;

int digits = 16;
FILE *fpoinc;
int event = -1;
int back = 0;

void mp_getY (mpfr_t Y, mpfr_t x, mpfr_t C) {
	mpfr_t aux, aux2;
	mpfr_inits (aux, aux2, (mpfr_ptr) 0);

	mpfr_mul (Y, x, x, MPFR_RNDN);

	mpfr_si_sub (aux, 1, mu, MPFR_RNDN);
	mpfr_mul_si (aux, aux, 2, MPFR_RNDN);
	mpfr_add (aux2, x, mu, MPFR_RNDN);
	mpfr_div (aux, aux, aux2, MPFR_RNDN);
	mpfr_add (Y, Y, aux, MPFR_RNDN);

	mpfr_sub_si (aux2, aux2, 1, MPFR_RNDN);
	mpfr_mul_si (aux, mu, 2, MPFR_RNDN);
	mpfr_div (aux, aux, aux2, MPFR_RNDN);
	mpfr_add (Y, Y, aux, MPFR_RNDN);

	mpfr_sub (Y, Y, C, MPFR_RNDN);

	mpfr_sqrt (Y, Y, MPFR_RNDN);
	mpfr_mul_si (Y, Y, -1, MPFR_RNDN);

	mpfr_clears (aux, aux2, (mpfr_ptr) 0);
	//return -sqrt (x*x + 2.*(1-mu)/(x+mu) + 2.*mu/(x-1+mu) - C);
}

/*-1.5355000000000001e+00  -1.3926873272597691e+00  3.0320898333517249e+01
-1.5358098731632210e+00  -1.3919999999999990e+00  3.0319395057612251e+01*/
    


int main () {
	int precision = (int) ceil (digits * 3.321928);
	mpfr_set_default_prec (precision);

	int i;
	mpfr_inits (mu, unomenosmu, (mpfr_ptr) 0);
	mpfr_set_str (mu, "0.012277471", 10, MPFR_RNDN);
	mpfr_set_str (unomenosmu, "0.987722529", 10, MPFR_RNDN);

	mpfr_t x, C, T, x0[12], t0, tol, delta;
	mpfr_inits (x, C, T, t0, tol, delta, (mpfr_ptr) 0);
	for (i=0; i<12; i++) mpfr_init (x0[i]);
    
	mpfr_set_str (x, "0.994", 10, MPFR_RNDN);
	mpfr_set_str (C, "2.8564125202098700e+00", 10, MPFR_RNDN);
	mpfr_set_str (T, "1.7065216560157900e+01", 10, MPFR_RNDN);
	int nt = 1;


	mpfr_set_si (t0, 0, MPFR_RNDN);
	mpfr_set_str (tol, "1e-18", 10, MPFR_RNDN);
	mpfr_div_si (delta, T, nt, MPFR_RNDN);


	for (i=0; i<12; i++) mpfr_set_si (x0[i], 0, MPFR_RNDN);
	mpfr_set (x0[0], x, MPFR_RNDN);
	mp_getY (x0[3], x, C);
	mpfr_set_si (x0[4], 1, MPFR_RNDN);
	mpfr_set_si (x0[11], 1, MPFR_RNDN);
	
	mp_taylor (12, x0, t0, delta, nt, tol, stdout);

	mpfr_clears (x, C, T, t0, tol, delta, (mpfr_ptr) 0);
	for (i=0; i<12; i++) mpfr_clear (x0[i]);
	return 1;

}
