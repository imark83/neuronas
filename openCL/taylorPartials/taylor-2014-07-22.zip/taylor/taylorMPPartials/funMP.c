#include "funMP.h"


int NDER = 2;
int nvar = 4;

static int  P_ACCUM[4] = {0,1,3,5};
static int  P_COEF[5] = {1,1,1,1,1};
static int  P_VI[5] = {0,0,1,0,2};
static int  P_IV[5] = {0,1,0,2,0};

static int  PSTAR_ACCUM[4] = {0,1,2,3};
static int  PSTAR_COEF[3] = {0,1,1};
static int  PSTAR_VI[3] = {0,0,0};
static int  PSTAR_IV[3] = {0,1,2};


extern mpfr_t mu;
extern mpfr_t unomenosmu;

int getNCols () {
	return 12;
}


void mp_fun (int ncol, int order, mpfr_t t, mpfr_t x[ncol], 
		mpfr_t series[ncol][order+1]) {
	int i, j, k;
	static int unavez = 1;

	mpfr_t aux;
	mpfr_init (aux);

	if (unavez) {
		derInit (P_ACCUM, P_COEF, P_VI, P_IV, PSTAR_ACCUM, PSTAR_COEF, PSTAR_VI, PSTAR_IV); 
		unavez = 0;
	}
	
	mpfr_t l[23][NDER+1][order+1];
	mpfr_t v[4][NDER+1][order+1];		//para las variables

		for (k=0; k<23; k++) for (i=0; i<=NDER; i++) for (j=0; j<=order; j++) 
			mpfr_init (l[k][i][j]);
		for (k=0; k<4; k++) for (i=0; i<=NDER; i++) for (j=0; j<=order; j++) 
			mpfr_init (v[k][i][j]);

	for (k=0; k<nvar; k++) for (i=0; i<=NDER; i++) 
			mpfr_set (v[k][i][0], x[k+nvar*i], MPFR_RNDN);


	for (j=0; j<order; j++) { 
		mp_smCAD (j, l[0], v[0], mu);
		mp_sbCAD (j, l[1], v[0], unomenosmu);
		mp_mulAD (j, l[2], l[0], l[0]);
		mp_mulAD (j, l[3], l[1], l[1]);
		mp_mulAD (j, l[4], v[1], v[1]);
		mp_sumAD (j, l[5], l[2], l[4]);		//r_1^2
		mp_sumAD (j, l[6], l[3], l[4]);		//r_2^2
			mpfr_set_str (aux, "-1.5", 10, MPFR_RNDN);
		mp_powAD (j, l[7], l[5], aux);		//r_1^(-3/2)
		mp_powAD (j, l[8], l[6], aux);		//r_2^(-3/2)

		mp_mlCAD (j, l[9], l[7], unomenosmu);
		mp_mlCAD (j, l[10], l[8], mu);
		mp_mulAD (j, l[11], l[0], l[9]);
		mp_mulAD (j, l[12], l[1], l[10]);
			mpfr_set_str (aux, "2", 10, MPFR_RNDN);
		mp_mlCAD (j, l[13], v[3], aux);
		mp_sumAD (j, l[14], l[13], v[0]);
		mp_subAD (j, l[15], l[14], l[11]); 
		mp_subAD (j, l[16], l[15], l[12]);	//X'
		mp_mulAD (j, l[17], l[9], v[1]);
		mp_mulAD (j, l[18], l[10], v[1]);
			mpfr_set_str (aux, "-2", 10, MPFR_RNDN);
		mp_mlCAD (j, l[19], v[2], aux);
		mp_sumAD (j, l[20], l[19], v[1]);
		mp_subAD (j, l[21], l[20], l[17]);
		mp_subAD (j, l[22], l[21], l[18]);	//Y'

		for (i=0; i<=NDER; i++) {
			mpfr_div_si (v[0][i][j+1], v[2][i][j], j+1., MPFR_RNDN);
			mpfr_div_si (v[1][i][j+1], v[3][i][j], j+1., MPFR_RNDN);
			mpfr_div_si (v[2][i][j+1], l[16][i][j], j+1., MPFR_RNDN);
			mpfr_div_si (v[3][i][j+1], l[22][i][j], j+1., MPFR_RNDN);
		}
	}
	for (k=0; k<nvar; k++) for (i=0; i<=NDER; i++) for (j=0; j<=order; j++)  {
		mpfr_set (series[k+i*nvar][j], v[k][i][j], MPFR_RNDN);
	}


	/*LIMPIEZA*/
	for (k=0; k<23; k++) for (i=0; i<=NDER; i++) for (j=0; j<=order; j++) 
		mpfr_clear (l[k][i][j]);
	for (k=0; k<4; k++) for (i=0; i<=NDER; i++) for (j=0; j<=order; j++) 
			mpfr_init (v[k][i][j]);
	mpfr_clear (aux);
}

void printFunctions (FILE *fout, mpfr_t x[], int digits) {
	//fprintf (fout, "  %.16le", getEnergy (x));
}


void getEnergy (mpfr_t E, mpfr_t x[]) {
	/*double r1 = sqrt ((x[0]+mu)*(x[0]+mu) + x[1]*x[1]);
	double r2 = sqrt ((x[0]-unomenosmu)*(x[0]-unomenosmu) + x[1]*x[1]);


	return x[0]*x[0] + x[1]*x[1] + 2.*unomenosmu/r1 + 2*mu/r2 -x[2]*x[2] - x[3]*x[3];*/
}


void mp_funBack (int ncol, int order, mpfr_t t, mpfr_t x[ncol], 
		mpfr_t series[ncol][order+1]) {}
