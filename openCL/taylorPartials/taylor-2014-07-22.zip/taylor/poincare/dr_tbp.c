#include "taylor.h"
#include <math.h>

int kahan = 1;
int fac = 1;
int event = 1;
FILE *fpoinc;

double getY (double x, double H);

int main () {
	int i;
	int nvar = 4;

	FILE *finp = fopen ("chA1.ops", "r");
	FILE *fout = fopen ("chA1Full.ops", "w");

	double x[nvar];
	double t0 = 0.;
	double tf ;
	int nt = 1;
	double tol = 1e-18;
	int m;
	double H;
	do {
		fscanf (finp, "%le %le %i %le\n", &x[0], &H, &m, &tf);
		x[1] = 0.;
		x[2] = 0.;
		x[3] = getY (x[0], H);

		fpoinc = fopen ("aux.txt", "w");

		taylor (nvar, x, t0, tf/nt, nt, tol, stdout);
		fclose (fpoinc);
		
		fpoinc = fopen ("aux.txt", "r");
		fscanf (fpoinc, "%le %le %le %le\n", &x[0], &x[1], &x[2], &x[3]);
		fprintf (fout, "%.16le ", x[0]);
		for (i=0; i<m-1; i++) {
			fscanf (fpoinc, "%le %le %le %le", &x[0], &x[1], &x[2], &x[3]);
			fprintf (fout, "%.16le %.16le ", x[0], x[2]);
		}
		fprintf (fout, "%.16le %1i\n", H, m);
		fclose (fpoinc);return;
		remove ("aux.txt");
	} while (!feof (finp));

	fclose (fout);
	fclose (finp);
	
	return 1;
}


double getY (double x, double H) {
	double r1, r2;
	r1 = 0.5 - x;
	r2 = -0.5 - x;

	return sqrt (2.*H + x*x + 1./r1 + 1./r2);

}
