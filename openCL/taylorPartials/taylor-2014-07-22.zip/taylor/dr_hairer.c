#include <stdlib.h>
#include "taylor.h"

double getRand ();


int kahan = 1;
int fac = 1;
int main () {
	int nvar = 3, i, j;

	double x[nvar], C, E, CSol = 0.5, ESol = 7.4794671194265039e-01, t;
	double t0 = 0.;
	double tf = 1000000.;
	int nt = 200;
	double tol = 1e-20;

	x[0] = 0.5;
	x[1] = 0.2;
	x[2] = sqrt (1-x[0]*x[0] - x[1]*x[1]);

	FILE *fout;
	FILE *fEn = fopen ("hairerTestEnergy.txt", "w");
	FILE *fCa = fopen ("hairerTestCasimir.txt", "w");

	fprintf (fEn, "%le", 0.);
	for (i=1; i<=nt; i++) fprintf (fEn, "  %le", tf/nt*i);
	fprintf (fEn, "\n");

	fprintf (fCa, "%le", 0.);
	for (i=1; i<=nt; i++) fprintf (fCa, "  %le", tf/nt*i);
	fprintf (fCa, "\n");

	for (i=0; i<1; i++) {
		x[0] = 0.5 + getRand()*1.e-10;
		x[1] = 0.2 + getRand()*1.e-10;
		x[2] = sqrt (1-x[0]*x[0] - x[1]*x[1]);
		fout  = fopen ("aux.dat", "w");
		taylor (nvar, x, t0, tf/nt, nt, tol, fout);
		fclose (fout);

		fout = fopen ("aux.dat", "r");

		fscanf (fout, "%le  %le  %le  %le  %le  %le\n", 
			&t, &x[0], &x[1], &x[2], &ESol, &C);
		fprintf (fEn, "%.16le ", E-ESol);
		fprintf (fCa, "%.16le ", C-CSol);

		for (j=1; j<=nt; j++) {
			fscanf (fout, "%le  %le  %le  %le  %le  %le\n", 
				&t, &x[0], &x[1], &x[2], &E, &C);
			fprintf (fEn, "%.16le ", E-ESol);
			fprintf (fCa, "%.16le ", C-CSol);
		}
		fprintf (fEn, "\n");
		fprintf (fCa, "\n");
		fclose (fout);
		remove ("aux.dat");
	}

	fclose (fEn); fclose (fCa);

	return 1;
}


double getRand () {
        srand (time (NULL)*getpid());
        return rand ()/((float) RAND_MAX)*2. - 1.;

}

