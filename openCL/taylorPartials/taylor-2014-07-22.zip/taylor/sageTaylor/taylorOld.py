def create_lists(_f, pars):
    vars = _f[0].arguments()
    f=_f(*vars).function(list(vars) + list(pars))
    """
    - f is a vectorial function f(x1, x2, ...) -> [...]

    Create two lists:

    - The first list contains the subexpressions that appear in the construction
    of the function

    - The second one contains the corresponding operation used to create each subexpression
    """
    varpar = list(vars) + list(pars)
    lis = flatten([fast_callable(i,vars=varpar).op_list() for i in f], max_level=1)
    stack = []
    stackSymbol=[]
    stackString=[]
    for i in lis:
        if i[0] == 'load_arg':
            stack.append(varpar[i[1]])
        elif i[0] == 'ipow':
            if i[1] in NN:
                basis = stack[-1]
                for j in range(i[1]-1):
	            a=stack.pop(-1)
	            stackString.append(('mul', a, basis))
	            stack.append(a*basis)
	            stackSymbol.append(stack[-1])
            else:
                stackString.append(('pow',stack[-1],i[1]))
                stack[-1]=stack[-1]**i[1]
                stackSymbol.append(stack[-1])

        elif i[0] == 'load_const':
            stack.append(i[1])
        elif i == 'mul':
            a=stack.pop(-1)
            b=stack.pop(-1)
            stackString.append(('mul', a, b))
            stack.append(a*b)
            stackSymbol.append(stack[-1])

        elif i == 'div':
            a=stack.pop(-1)
            b=stack.pop(-1)
            stackString.append(('div', a, b))
            stack.append(b/a)
            stackSymbol.append(stack[-1])

        elif i == 'add':
            a=stack.pop(-1)
            b=stack.pop(-1)
            stackString.append(('add',a,b))
            stack.append(a+b)
            stackSymbol.append(stack[-1])

        elif i == 'pow':
            a=stack.pop(-1)
            b=stack.pop(-1)
            stackString.append(('pow', b, a))
            stack.append(b**a)
            stackSymbol.append(stack[-1])

        elif i[0] == 'py_call' and str(i[1])[10:14] == 'sqrt':
            a=stack.pop(-1)
            stackString.append(('pow', a, 1.0/2.0))
            stack.append(sqrt(a))
            stackSymbol.append(stack[-1])

        elif i[0] == 'py_call' and str(i[1])=='log':
            a=stack.pop(-1)
            stackString.append(('log', a))
            stack.append(log(a))
            stackSymbol.append(stack[-1])

        elif i[0] == 'py_call' and str(i[1])=='exp':
            a=stack.pop(-1)
            stackString.append(('exp', a))
            stack.append(exp(a))
            stackSymbol.append(stack[-1])

        elif i[0] == 'py_call' and str(i[1])=='sin':
            a=stack.pop(-1)
            stackString.append(('sin', a))
            stackString.append(('cos', a))
            stackSymbol.append(sin(a))
            stackSymbol.append(cos(a))
            stack.append(sin(a))

        elif i[0] == 'py_call' and str(i[1])=='cos':
            a=stack.pop(-1)
            stackString.append(('sin', a))
            stackString.append(('cos', a))
            stackSymbol.append(sin(a))
            stackSymbol.append(cos(a))
            stack.append(cos(a))

        elif i == 'neg':
            a = stack.pop(-1)
            stackString.append(('mul', -1, a))
            stack.append(-a)
            stackSymbol.append(-a)

    return stackSymbol, stackString

def expresionIsConstant (ex,pars):
    return  (set(ex.variables()).issubset(set(pars)))

def remove_constants(l1,l2,pars):
    i=0
    constList1=[]
    constList2=[]
    while i < len(l1):
        if (l1[i] in RR):
            l1.pop(i)
            l2.pop(i)
        elif expresionIsConstant (l1[i], pars):
            constList1.append(l1.pop(i))
            constList2.append(l2.pop(i))
        else:
            i+=1
    return constList1, constList2


def remove_repeated(l1, l2):
    """
    rmoves the repeated elements of l1, and the elements of l2 that are in the same
    positions.
    """
    for i in range(len(l1)-1):
        j=i+1
        while j<len(l1):
            if l1[j] == l1[i]:
                l1.pop(j)
                l2.pop(j)
            else:
                j+=1

def const_code_list (cons1, cons2, pars):
    cons3=[]

    for i in cons2:
        oper = i[0]
        if oper in ["log", "exp", "sin", "cos"]:
            a = i[1]
            if a in pars:
                cons3.append ((oper, 'par[{}]'.format(par.index(a))))
            else:
                cons3.append ((oper, 'c[{}]'.format (cons1.index(a))))
        else:
            a=i[1]
            b=i[2]
            if a in pars:
                aa = 'par[{}]'.format(pars.index(a))
            elif a in cons1:
                aa = 'c[{}]'.format(cons1.index(a))
            else:
                aa = str(N(a))
            if b in pars:
                bb = 'par[{}]'.format(pars.index(b))
            elif b in cons1:
                bb = 'c[{}]'.format(cons1.index(b))
            else:
                bb = str(N(b))
            
            cons3.append ((oper, aa, bb))

    return cons3

def code_list(l1,l2,cons1,f,par):
    l3=[]
    var = f[0].arguments()
    for i in l2:
        oper = i[0]
        if oper in ["log", "exp", "sin", "cos"]:
            a = i[1]
            if a in var:
                l3.append((oper, 'series[{}]'.format(var.index(a)-1)))
            else:
                l3.append((oper, 'l[{}]'.format(l1.index(a))))

        else:
            a=i[1]
            b=i[2]
            consta=False
            constb=False

            if a in var:
                aa = 'series[{}]'.format(var.index(a)-1)
            elif a in l1:
                aa = 'l[{}]'.format(l1.index(a))
            else:
                consta=True
                if a in cons1:
                    aa = 'c[{}]'.format(cons1.index(a))
                elif a in par:
                    aa = 'par[{}]'.format(par.index(a))
                else:
                    aa = str(N(a))
            if b in var:
                bb = 'series[{}]'.format(var.index(b)-1)
            elif b in l1:
                bb = 'l[{}]'.format(l1.index(b))
            else:
                constb=True
                if b in cons1:
                    bb = 'c[{}]'.format(cons1.index(b))
                elif b in par:
                    bb = 'par[{}]'.format(par.index(b))
                else:
                    bb = str(N(b))
            if consta:
                oper += '_c'
                if not oper=='div':
                    bb, aa = aa,bb
            elif constb:
                oper += '_c'
            l3.append((oper, aa, bb))

    return l3

def sage_tides(f):
    l1,l2 = create_lists(f)
    remove_repeated(l1,l2)
    remove_constants(l1,l2)
    return code_list(l1,l2,f)

def const_parser_list (cons1, cons3):
    res = []
    for i in range(len(cons3)):
        codeLine = cons3[i]
        string = "\tc[{}] = ".format(i)
        if codeLine[0] == 'add':
            string += codeLine[1] + " + " + codeLine[2] + ";"
        if codeLine[0] == 'log':
            string += 'log (' + codeLine[1] + ");"
        res.append (string)

    return res

def parser_list(f, par):
    var = f[0].arguments()
    nvar = len(var)
    l1,l2 = create_lists(f,par)
    remove_repeated(l1,l2)
    cons1, cons2 = remove_constants(l1,l2,par)
    cons3 = const_code_list (cons1, cons2, par)
    l3 = code_list (l1, l2, cons1, f, par)
    res = []
    for i in range(len(l3)):
        codeLine = l3[i]
        string = "\t\t"
        if codeLine[0] == 'add':
            string += "dp_sumAD (i, l[{}], ".format(i) + codeLine[1] + ", " + codeLine[2] + ");"
        elif codeLine[0] == 'add_c':
            string += "dp_smCAD (i, l[{}], ".format(i) + codeLine[1] + ", " + codeLine[2] + ");"
        elif codeLine[0] == 'mul':
            string += "dp_mulAD (i, l[{}], ".format(i) + codeLine[1] + ", " + codeLine[2] + ");"
        elif codeLine[0] == 'mul_c':
            string += "dp_mlCAD (i, l[{}], ".format(i) + codeLine[1] + ", " + codeLine[2] + ");"
        elif codeLine[0] == 'pow_c':
            string += "dp_powAD (i, l[{}], ".format(i) + codeLine[1] + ", " + codeLine[2] + ");"
        elif codeLine[0] == 'div':
            string += "dp_divAD (i, l[{}], ".format(i) + codeLine[1] + ", " + codeLine[2] + ");"
        elif codeLine[0] == 'div_c':
            string += "dp_invAD (i, l[{}], ".format(i) + codeLine[1] + ", " + codeLine[2] + ");"
        elif codeLine[0] == 'log':
            string += "log_mc("+codeLine[1]+",XX[{}], i);".format(i+n)
        elif codeLine[0] == 'exp':
            string += "exp_mc("+codeLine[1]+",XX[{}], i);".format(i+n)
        elif codeLine[0] == 'sin':
            string += "sin_mc("+codeLine[1]+",XX[{}], i);".format(i+n+1)
        elif codeLine[0] == 'cos':
            string += "cos_mc("+codeLine[1]+",XX[{}], i);".format(i+n-1)


        res.append(string)

    res.append("\n")
    l1 = list(var)+l1
    indices = [l1.index(i(*var))+nvar for i in f]
    for i in range (1,len(var)):
        aux = indices[i-1] - len(var)
        if aux < len(var):
            res.append("\t\tseries[{}][i+1] = series[{}][i] / (i+1.0);".format(i-1, aux - 1))
        else:
            res.append("\t\tseries[{}][i+1] = l[{}][i] / (i+1.0);".format(i-1, aux - len(var)))

    return res, cons1, cons3


def genCode(f,par):
    parsed, cons1, cons3 = parser_list(f, par)
    const_parsed = const_parser_list (cons1, cons3)
    if len(parsed) - len(f[0].arguments()) > 0:
        print "\tdouble l[{}][order];".format(len(parsed)-len(f[0].arguments()))
    if len(const_parsed) > 0:
        print "\tdouble c[{}];".format(len(const_parsed))
    for s in const_parsed:
        print s
    print "\tfor (i=0; i<order; i++) {"
    for s in parsed:
        print s
    print "\t}"

def gendriver(nvars, fname, fileoutput, initial_values, initial=0.0, final = 100.0,
              delta=0.5, tolrel=1e-16, tolabs=1e-16):
    os.system("cat driverFile00.txt > " + fname)
    outfile = open(fname, 'a')
    outfile.write('\n\tVARS = {} ;\n'.format(nvars-1))
    outfile.write('\tPARS = 1;\n')
    outfile.write('\tdouble tolrel, tolabs, tini, tend, dt; \n')
    outfile.write('\tdouble v[VARS], p[PARS]; \n')
    for i in range(len(initial_values)):
        outfile.write('\tv[{}] = {} ; \n'.format(i, initial_values[i]))
    outfile.write('\ttini = {} ;\n'.format(initial))
    outfile.write('\ttend = {} ;\n'.format(final))
    outfile.write('\tdt   = {} ;\n'.format(delta))
    outfile.write('\ttolrel = {} ;\n'.format(tolrel))
    outfile.write('\ttolabs = {} ;\n'.format(tolabs))
    outfile.write('\textern char ofname[20];')
    outfile.write('\tstrcpy(ofname, "'+ fileoutput +'");\n')
    outfile.write('\tminc_tides(v,VARS,p,PARS,tini,tend,dt,tolrel,tolabs);\n')
    outfile.write('\treturn 0; \n }')
    outfile.close()

def salida(f, initial_values, filename, initial = 0, final = 100.0, delta = 0.5):
    n = len(f[0].arguments())
    genCodeSeries(f, 'integrator.c')
    gendriver(n, 'driver.c', filename, initial_values, initial, final, delta)
    os.system('gcc -o runme integrator.c driver.c minc_tides.c -lm -O3')
    os.system('./runme ')
    outfile = open(filename)
    res = outfile.readlines()
    outfile.close()
    for i in range(len(res)):
        l=res[i]
        l = l.split(' ')
        l = filter(lambda a: len(a) > 2, l)
        res[i] = map(RR,l)
    return res






