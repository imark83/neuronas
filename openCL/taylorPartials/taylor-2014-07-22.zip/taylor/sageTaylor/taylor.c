#include "taylor.h"

//extern int kahan;
extern int event;
extern FILE *fpoinc;
static int i=0;


FILE *fpoinc;
int kahan = 0;

int count;
void taylor (int nvar, double x[nvar], double t0, double delta, int nt, double tol, FILE *fout) {
	count = 0;
	int nsteps = 0;
	int denseStep = 0;
	int i, j;
	int order = getOrder (tol); 


	double series[nvar][order+1];	//para guardar la serie de taylro
	double dt;			//distancia para evaluar la serie
	double xx[nvar];		//puntos para la salida densa
	double t;			//posicion de la integracion
	double tt; 			//posicion de la salida densa
	volatile double step;		//paso
	volatile double kahan_y;
	volatile double kahan_t;
	volatile double kahan_c = 0.;
	volatile double kahan_cc = 0.;
	volatile double kahan_ccc = 0.;


/*******************************************
******* POINCARE*/
	double criterion, pCut[nvar], tCut, y_old;

/******** 
*******************************************/

	t = tt = t0;
	dt = 0.;

	while (denseStep < nt +1) {
		fun (nvar, order, t, x, series);
		step = getStep (nvar, order, series, tol);
		nsteps++;
		

	/*******************************************
	******* SALIDA DENSA*/
		while ((step > dt) && (denseStep < nt+1)) {
			horner (nvar, order, dt, series, xx);
			if (fout != NULL) {
				fprintf (fout, "%.16le", tt);
				for (i=0; i<nvar; i++)
					fprintf (fout, "  %.16le", xx[i]);
				printFunctions (fout, xx);
				fprintf (fout, "\n");
			}

			if (kahan) {
				kahan_y = delta - kahan_cc;
				kahan_t = dt + kahan_y;
				kahan_cc = (kahan_t - dt) - kahan_y;
				dt = kahan_t;

				kahan_y = delta - kahan_ccc;
				kahan_t = tt + kahan_y;
				kahan_ccc = (kahan_t - tt) - kahan_y;
				tt = kahan_t;
			} else {
				dt = dt + delta;
				tt = tt + delta;
			}
			denseStep++;
		}


	/******** 
	*******************************************/

	/*******************************************
	******* POINCARE*/
		if (event >= 0)	y_old = x[event];	
	/******** 
	*******************************************/
		
		horner (nvar, order, step, series, x);


	/*******************************************
	******* POINCARE*/
		if (event >= 0)	{
			criterion = y_old * x[event];
			if (criterion < 0) {
				poincare (nvar, order, step, series, event, pCut, &tCut);
				tCut = tCut + t;
				fprintf (fpoinc, "\n%.16le", tCut);
				for (i=0; i<nvar; i++)
					fprintf (fpoinc, "  %.16le", pCut[i]);
				fprintf (fpoinc, "\n\n");
				if (count == 11) return;
				count++;
			}

		}
	/******** 
	*******************************************/
		
		if (kahan) {
			kahan_y = step - kahan_c;
			kahan_t = t + kahan_y;
			kahan_c = (kahan_t - t) - kahan_y;
			t = kahan_t;
		}
		else {t = t + step;}

	// CORREGIR!!!! FALTA PONER AQUI KAHAN
		dt = dt - step;

	}


/*******************************************
******* SALIDA FINAL DE LAS VARIABLES*/
	for (i=0; i<nvar; i++) x[i] = xx[i];
//	printf ("nsteps = %i\n", nsteps);
/******** 
*******************************************/


}


void poincare (int nvar, int order, double step, double series[nvar][order+1], int event, 
		double rop[nvar], double *dt) {
	double h_L = 0., h_R = step, h_M;
	double p_L, p_R, p_M, x[nvar];
	double error;
	horner (nvar, order, h_R, series, x);
	do {
		horner (nvar, order, h_L, series, x); 
		p_L = x[event];
		horner (nvar, order, h_R, series, x); 
		p_R = x[event];
		h_M = (h_L + h_R)/2.;
		horner (nvar, order, h_M, series, x); 
		p_M = x[event];
		if (p_M * p_L < 0.) 
			h_R = h_M;
		else 
			h_L = h_M;
		error = p_M;
	} while (fabs (p_M) > 1e-15);
	horner (nvar, order, h_M, series, rop);
	*dt = h_M;
//	printf ("x = [%.16le, %.16le, %.16le, %.16le]\n", x[0], x[1], x[2], x[3]);
}


/*void taylor_old (int nvar, double x[nvar], double t0, double tf, double tol, FILE *fout) {

	int nsteps = 0, i, order = getOrder (tol); 
	double series[nvar][order+1];

	double t = t0;
	volatile double step, kahan_t, kahan_c = 0.;
	if (nsteps%fac == 0) {
		fprintf (fout, "%.16le", t);
		for (i=0; i<nvar; i++) fprintf (fout, "  %.16le", x[i]);
		printFunctions (fout, x);
		fprintf (fout, "\n");
	}
	while (t < tf) {
		fun (nvar, order, t, x, series); 
		step = getStep (nvar, order, series, tol);
		nsteps++;

		if (kahan) {
			step = step - kahan_c;
			kahan_t = t + step;
			kahan_c = (kahan_t - t) - step;
			t = kahan_t;
		} else t = t+step;
		horner (nvar, order, step, series, x); 
		if (nsteps%fac == 0) {
			fprintf (fout, "%.16le", t);
			for (i=0; i<nvar; i++) fprintf (fout, "  %.16le", x[i]);
			printFunctions (fout, x);
			fprintf (fout, "\n");
		} 
  

	}
	printf ("nsteps = %i\n", nsteps);

}*/


int getOrder (double tol) {
	return ceil (-log(tol)/2.);	
}

double getStep (int nvar, int order, double series[nvar][order+1], 
		double tol) {
	double n1, n2;
	double x1[nvar], x2[nvar];
	int i;
	for (i=0; i<nvar; i++) {
		x1[i] = series[i][order];
		x2[i] = series[i][order-1];
	}
	n1 = normInf (nvar, x1); n2 = normInf (nvar, x2);
	double h1, h2;

	h1 = pow ((tol/n1), 1./order);
	h2 = pow ((tol/n2), 1./(order-1));
	
	if (h1 < h2) return h1;
	return h2;
}

void horner (int nvar, int order, double h, double series[nvar][order+1], 
		double rop[nvar]) {
	int i, j;
	
	for (i=0; i<nvar; i++) rop[i] = series[i][order];
	for (i=order-1; i>=0; i--)
		for (j=0; j<nvar; j++) 
			rop[j] = rop[j]*h + series[j][i];
}

double normInf (int nvar, double x[nvar]) {
	double rop = 0.;
	int i;
	for (i=0; i<nvar; i++) 
		if (fabs (x[i]) > rop) rop = fabs (x[i]);
	return rop;

}
