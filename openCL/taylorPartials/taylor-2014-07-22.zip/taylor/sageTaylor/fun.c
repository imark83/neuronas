#include "fun.h"


void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	double par[] = {0.012277471};

// BEGIN OF SAGE-GENERATED CODE
         double l[27][order];
        double c[1];
        c[0] = -1.00000000000000 + par[0];
        for (i=0; i<order; i++) {
                dp_mlCAD (i, l[0], series[3], 2.00000000000000);
                dp_sumAD (i, l[1], series[0], l[0]);
                dp_smCAD (i, l[2], series[0], par[0]);
                dp_mulAD (i, l[3], l[2], l[2]);
                dp_mulAD (i, l[4], series[1], series[1]);
                dp_sumAD (i, l[5], l[4], l[3]);
                dp_powAD (i, l[6], l[5], -1.50000000000000);
                dp_mulAD (i, l[7], l[2], l[6]);
                dp_mlCAD (i, l[8], l[7], c[0]);
                dp_sumAD (i, l[9], l[8], l[1]);
                dp_smCAD (i, l[10], l[2], -1.00000000000000);
                dp_mulAD (i, l[11], l[10], l[10]);
                dp_sumAD (i, l[12], l[4], l[11]);
                dp_powAD (i, l[13], l[12], -1.50000000000000);
                dp_mulAD (i, l[14], l[10], l[13]);
                dp_mlCAD (i, l[15], l[14], par[0]);
                dp_mlCAD (i, l[16], l[15], -1.00000000000000);
                dp_sumAD (i, l[17], l[16], l[9]);
                dp_mlCAD (i, l[18], series[2], -2.00000000000000);
                dp_sumAD (i, l[19], series[1], l[18]);
                dp_mlCAD (i, l[20], l[6], c[0]);
                dp_mulAD (i, l[21], series[1], l[20]);
                dp_sumAD (i, l[22], l[21], l[19]);
                dp_mlCAD (i, l[23], l[13], par[0]);
                dp_mulAD (i, l[24], series[1], l[23]);
                dp_mlCAD (i, l[25], l[24], -1.00000000000000);
                dp_sumAD (i, l[26], l[25], l[22]);


                series[0][i+1] = series[2][i] / (i+1.0);
                series[1][i+1] = series[3][i] / (i+1.0);
                series[2][i+1] = l[17][i] / (i+1.0);
                series[3][i+1] = l[26][i] / (i+1.0);
        }
// END OF SAGE-GENERATED CODE

}

void printFunctions (FILE *fout, double x[]) {
//	fprintf (fout, "  %.16le", getEnergy (x));
}


double getEnergy (double x[]) {
}

