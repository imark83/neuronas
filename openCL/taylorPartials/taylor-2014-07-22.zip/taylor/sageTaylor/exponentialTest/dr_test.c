#include "taylor.h"

extern int kahan;
int event = -1;
int fac = 1;
int main () {
	int nvar = 3;

	double x[nvar];
	double t0 = 0.;
	double tf = 3.;
	int nt = 1;
	double tol = 1e-18;
	x[0] = 1.0;
	x[1] = 0.0;
	x[2] = 1.0;

	//FILE *fout = fopen ("testExp.txt", "w");
	FILE *fout = stdout;

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	//fclose (fout);
	
	return 1;
}

