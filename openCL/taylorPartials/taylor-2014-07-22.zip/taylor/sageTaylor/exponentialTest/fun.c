#include "fun.h"


void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	//double par[] = {0.012277471};

// BEGIN OF SAGE-GENERATED CODE
        double T[order];
        for (i=2; i<order; i++) T[i] = 0.0;
        T[0] = t;
        T[1] = 1.0;
        double l[4][order];
        for (i=0; i<order; i++) {
                dp_mlCAD (i, l[0], T, -2.00000000000000);
                dp_expAD (i, l[1], l[0]);
                dp_mlCAD (i, l[2], l[1], -2.00000000000000);
                dp_mlCAD (i, l[3], series[1], -1.00000000000000);


                series[0][i+1] = l[2][i] / (i+1.0);
                series[1][i+1] = series[2][i] / (i+1.0);
                series[2][i+1] = l[3][i] / (i+1.0);
        }
// END OF SAGE-GENERATED CODE

}

void printFunctions (FILE *fout, double x[]) {
//	fprintf (fout, "  %.16le", getEnergy (x));
}


double getEnergy (double x[]) {
}

