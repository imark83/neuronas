#include "taylor.h"

/* SAGE CODE FOR AD: (
sage: attach ('./taylor.py')
sage: var('t, x, y, X, Y, mu')
sage: pars = [mu]
sage: d1=((x+mu)^2+y^2)^(3/2)
sage: d2=((x-(1-mu))^2+y^2)^(3/2)
sage: f(t,x,y,X,Y)=[X,Y,x+2*Y-(1-mu)*(x+mu)/d1 - mu*(x-(1-mu))/d2, y-2*X - (1-mu)*y/d1 - mu*y/d2]
sage: generateCode (f, pars)

*/



extern int kahan;
int event = -1;
int fac = 1;
int main () {
	int nvar = 4;

	double x[nvar];
	double t0 = 0.;
	double tf = 17.065216560157962;
	int nt = 10000;
	double tol = 1e-18;
	x[0] = 0.994;
	x[1] = 0.;
	x[2] = 0.;
	x[3] = -2.0015851063790825;

	FILE *fout = fopen ("arenstorf.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	fclose (fout);
	
	return 1;
}

