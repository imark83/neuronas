#include "taylor.h"

extern int kahan;
int event = -1;
int fac = 1;
int main () {
	int nvar = 4;

	double x[nvar];
	double t0 = 0.;
	double tf = 17.065216560157962;
	int nt = 10000;
	double tol = 1e-18;
	x[0] = 0.994;
	x[1] = 0.;
	x[2] = 0.;
	x[3] = -2.0015851063790825;

	FILE *fout = fopen ("arenstorf.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	fclose (fout);
	
	return 1;
}

