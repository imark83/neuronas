#include "fun.h"
/*3 body problem*/

//double mu = 0.012277471, mmu = 0.987722529;
double mu = 0.5, mmu = 0.5;

void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	double l[21][order];

	for (i=0; i<order; i++) {
		dp_smCAD (i, l[0], series[0], mu);
		dp_mulAD (i, l[1], l[0], l[0]);
		dp_smCAD (i, l[2], series[0], -mmu);
		dp_mulAD (i, l[3], l[2], l[2]);
		dp_mulAD (i, l[4], series[1], series[1]);
		dp_sumAD (i, l[5], l[1], l[4]);
		dp_powAD (i, l[6], l[5], -1.5);
		dp_sumAD (i, l[7], l[3], l[4]);
		dp_powAD (i, l[8], l[7], -1.5);
		dp_mulAD (i, l[9], l[0], l[6]);
			l[9][i] *= -mmu;
		dp_mulAD (i, l[10], l[2], l[8]);
			l[10][i] *= -mu;
		dp_mulAD (i, l[11], series[1], l[6]);
			l[11][i] *= -mmu;
		dp_mulAD (i, l[12], series[1], l[8]);
			l[12][i] *= -mu;
		l[13][i] = 2.* series[3][i];
		dp_sumAD (i, l[14], series[0], l[13]);
		dp_sumAD (i, l[15], l[14], l[9]);
		dp_sumAD (i, l[16], l[15], l[10]);
		l[17][i] = -2.* series[2][i];
		dp_sumAD (i, l[18], l[17], series[1]);
		dp_sumAD (i, l[19], l[18], l[11]);
		dp_sumAD (i, l[20], l[19], l[12]);



		series[0][i+1] = series[2][i]/(i+1.);
		series[1][i+1] = series[3][i]/(i+1.);
		series[2][i+1] = l[16][i]/(i+1.);
		series[3][i+1] = l[20][i]/(i+1.);
	
	}


}

void printFunctions (FILE *fout, double x[]) {
//	fprintf (fout, "  %.16le", getEnergy (x));
}


