#include "taylor.h"

int kahan = 1;
int fac = 1;
int main () {
	int nvar = 4;

	double x[nvar];
	double t0 = 0.;
	double tf = 17.065216560157962;
	int nt = 1000;
	double tol = 1e-18;
	x[0] = -5;
	x[1] = 0.;
	x[2] = 0.;
	x[3] = 4.46500402469720402;

	FILE *fout = fopen ("copenhague.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	fclose (fout);
	
	return 1;
}

