#include "taylor.h"

int kahan = 1;
int fac = 1;
int main () {
	int nvar = 3;

	double x[nvar];
	double t0 = 0.;
	double tf = 100000000.;
	int nt = 2000;
	double tol = 1e-18;

	x[0] = 0.5;
	x[1] = 0.2;
	x[2] = sqrt (1-x[0]*x[0] - x[1]*x[1]);

	FILE *fout = fopen ("rb1.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);


	fclose (fout);
	
	return 1;
}

