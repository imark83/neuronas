#include "fun.h"

double I1 = 0.345;
double I2 = 0.653;
double I3 = 1.;

void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	double l[3][order+1];

	for (i=0; i<order; i++) {
		dp_mulAD (i, l[0], series[1], series[2]);
		dp_mulAD (i, l[1], series[0], series[2]);
		dp_mulAD (i, l[2], series[0], series[1]);
		l[0][i] *= (1./I3 - 1./I2); 
		l[1][i] *= (1./I1 - 1./I3);
		l[2][i] *= (1./I2 - 1./I1);
 
		series[0][i+1] = l[0][i]/(i+1);
		series[1][i+1] = l[1][i]/(i+1);
		series[2][i+1] = l[2][i]/(i+1); 
	}


}

void printFunctions (FILE *fout, double x[]) {
	fprintf (fout, "  %.16le  %.16le", getEnergy (x), getCasimir (x));
}

double getEnergy (double x[]) {
	return (x[0]*x[0]/I1 + x[1]*x[1]/I2 + x[2]*x[2]/I3)/2.;

}

double getCasimir (double x[]) {
	return (x[0]*x[0] + x[1]*x[1] + x[2]*x[2])/2.;
}
