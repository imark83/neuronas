clear;
rb1 = load ('rb0.txt');
rb2 = load ('rb1.txt');
rb3 = load ('rb2.txt');

err1(:,1) = rb1(:,1);
err2(:,1) = rb2(:,1);
err3(:,1) = rb3(:,1);

err1(:,2) = abs(rb1(:,5) - rb1(1,5));
err1(:,3) = abs(rb1(:,6) - rb1(1,6));
err2(:,2) = abs(rb2(:,5) - rb1(1,5));
err2(:,3) = abs(rb2(:,6) - rb1(1,6));
err3(:,2) = abs(rb3(:,5) - rb3(1,5));
err3(:,3) = abs(rb3(:,6) - rb3(1,6));

subplot (2,1,1)
loglog (err1(:,1), err1(:,2), 'm-');
hold on;
loglog (err2(:,1), err2(:,2), 'r-');
loglog (err3(:,1), err3(:,2), 'b-');
xlabel('time'); ylabel ('error');
title('Error in Energy');
legend ('tol = 10^{-14}','tol = 10^{-16}','tol = 10^{-18}');
axis([5e4, 1e8, 1e-16, 1e-8])
hold off;
subplot (2,1,2)
loglog (err1(:,1), err1(:,3), 'm-');
hold on;
loglog (err2(:,1), err2(:,3), 'r-');
loglog (err3(:,1), err3(:,3), 'b-');
xlabel('time'); ylabel ('error');
title('Error in Casimir');
legend ('tol = 10^{-14}','tol = 10^{-16}','tol = 10^{-18}');
axis([5e4, 1e8, 1e-16, 1e-8])
