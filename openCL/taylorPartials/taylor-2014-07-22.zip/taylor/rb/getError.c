#include <stdio.h>
#include <math.h>

void getError (FILE *finp, FILE *fout);

int main () {
	FILE *finp, *fout;

	finp = fopen ("rb1.txt", "r");
	fout = fopen ("rb1Err.txt", "w");
	getError (finp, fout);
	fclose (finp); fclose (fout);

	finp = fopen ("rb2.txt", "r");
	fout = fopen ("rb2Err.txt", "w");
	getError (finp, fout);
	fclose (finp); fclose (fout);
}

void getError (FILE *finp, FILE *fout) {

	double t, e, c, eSol, cSol;
	int i;

	fscanf (finp, "%le", &t);
	for (i=0; i<3; i++) fscanf (finp, "  %le", &e);
	fscanf (finp, "  %le  %le\n", &eSol, &cSol);

	while (!feof (finp)) {
		fscanf (finp, "%le", &t);
		for (i=0; i<3; i++) fscanf (finp, "  %le", &e);
		fscanf (finp, "  %le  %le\n", &e, &c);

		fprintf (fout, "%.16le  %.16le  %.16le\n",
			t, fabs (e-eSol), fabs (c-cSol));


	}
}
