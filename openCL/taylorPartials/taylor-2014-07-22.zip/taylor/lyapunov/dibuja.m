clear;


aaa = load ('lyapunovUnstable.txt' );


y0 = norm(aaa(1,6:9),2);
for i=2:154
	aaa(i,11) = (log(norm(aaa(i,6:9),2)) - log(y0))/aaa(i,1);
end

semilogx(aaa(:,1), aaa(:,11), '-b');
