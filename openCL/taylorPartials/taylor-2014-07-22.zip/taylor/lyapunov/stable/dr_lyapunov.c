#include "taylor.h"

int kahan = 1;
int fac = 1;
int event = -1;
FILE *fpoinc;
int main () {
	int nvar = 8;

	double x[nvar];
	double t0 = 0.;
	double tf = 100000;
	int nt = 1000;
	double tol = 1e-18;
	x[0] = 0.;
	x[1] = 0.2;
	x[2] = 0.46404022814119610;
	x[3] = 0.;
	x[4] = 1.;
	x[5] = 1.;
	x[6] = 1.;
	x[7] = 1.;

	fpoinc = stdout;


	FILE *fout = fopen ("lyapunovStable.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	fclose (fout);
	
	return 1;
}

