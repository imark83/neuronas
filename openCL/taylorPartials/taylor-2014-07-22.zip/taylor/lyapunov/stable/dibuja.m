clear;


aaa = load ('lyapunovStable.txt' );


y0 = norm(aaa(1,6:9),2)
for i=2:1001
	aaa(i,11) = log(norm(aaa(i,6:9),2)/y0)/aaa(i,1);
end
