#include "taylor.h"

int kahan = 1;
int fac = 1;
int event = -1;
FILE *fpoinc;
int main () {
	int nvar = 8;

	double x[nvar];
	double t0 = 0.;
	double tf = 100000;
	int nt = 1000;
	double tol = 1e-18;
	x[0] = 0.;
	x[1] = -0.2;
	x[2] = 0.452401002061961249;
	x[3] = 0.;
	x[4] = 1e-8;
	x[5] = 1e-8;
	x[6] = 1e-8;
	x[7] = 1e-8;

	fpoinc = stdout;


	FILE *fout = fopen ("lyapunovUnstable.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	fclose (fout);
	
	return 1;
}

