#ifndef _taylorAD_h
#define _taylorAD_h
#include <stdio.h>
#include <math.h>

void dp_sumAD (int order, double *rop, double *op1, 
		double *op2);
void dp_smCAD (int order, double *rop, double *op1, 
		double op2); 
void dp_subAD (int order, double *rop, double *op1, 
		double *op2);
void dp_mulAD (int order, double *rop, double *op1, 
		double *op2);
void dp_mlCAD (int order, double *rop, double *op1,
		double op2);
void dp_divAD (int order, double *rop, double *op1,
		double *op2);
void dp_invAD (int order, double *rop, double *op,
		double cte);
void dp_powAD (int order, double *rop, double *op1,
		double op2);
void dp_expAD (int order, double *rop, double *op);
void dp_logAD (int order, double *rop, double *op);
void dp_sinAD (int order, double *rop, double *op, 
		double *cosSeries);
void dp_cosAD (int order, double *rop, double *op, 
		double *sinSeries);

#endif
