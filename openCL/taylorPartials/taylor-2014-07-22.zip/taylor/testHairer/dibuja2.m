clear
cas = load('hairerTestCasimir.txt');
cas = cas';


muC = zeros (201,1);
for i=1:201
	for j=2:1001
		muC(i) = muC(i) + cas(i,j);
	end
	muC(i) = muC(i) / 1000;
end

sigmaC = zeros (201,1);
for i=1:201
	for j=2:1001
		sigmaC(i) = sigmaC(i) + (cas(i,j) - muC(i))^2;
	end
	sigmaC(i) = sqrt (sigmaC(i) / 1000);
end



en = load('hairerTestEnergy.txt');
en = en';
en(1,:) = zeros(1,1001);


muE = zeros (201,1);
for i=1:201
	for j=2:1001
		muE(i) = muE(i) + en(i,j);
	end
	muE(i) = muE(i) / 1000;
end

sigmaE = zeros (201,1);


for i=1:201
	for j=2:1001
		sigmaE(i) = sigmaE(i) + (en(i,j) - muE(i))^2;
	end
	sigmaE(i) = sqrt (sigmaE(i) / 1000);
end



%histograma

barC = zeros(6,1);
for i=1:1001
	if (cas(end,i) <-1e-13) barC(1) = barC(1) + 1;
	elseif (cas(end,i) < -5e-14) barC(2) = barC(2) + 1;
	elseif (cas(end,i) < 0) barC(3) = barC(3) + 1;
	elseif (cas(end,i) < 5e-14) barC(4) = barC(4) + 1;
	elseif (cas(end,i) < 1e-13) barC(5) = barC(5) + 1;
	else barC(6) = barC(6) + 1;
	end
end

barE = zeros(8,1);
for i=1:1001
	if (en(end,i) <-1.5e-13) barE(1) = barE(1) + 1;
	elseif (en(end,i) < -1e-13) barE(2) = barE(2) + 1;
	elseif (en(end,i) < -0.5e-13) barE(3) = barE(3) + 1;
	elseif (en(end,i) < 0) barE(4) = barE(4) + 1;
	elseif (en(end,i) < 0.5e-13) barE(5) = barE(5) + 1;
	elseif (en(end,i) < 1e-13) barE(6) = barE(6) + 1;
	elseif (en(end,i) <1.5e-13) barE(7) = barE(7) + 1;
	else barE(8) = barE(8) + 1;
	end
end


subplot (3,2,1)
plot (en(:,1), muC, '-b')
tics('x',[0 2e5 4e5 6e5 8e5 1e6], ['0';'2e5';'4e5';'6e5';'8e5';'1e6'])
title('Casimir');
xlabel('t'); ylabel('\mu');

subplot (3,2,2)
plot (en(:,1), muE, '-b');
tics('x',[0 2e5 4e5 6e5 8e5 1e6], ['0';'2e5';'4e5';'6e5';'8e5';'1e6'])
title ('Energy');
xlabel('t'); ylabel('\mu');

subplot (3,2,3)
loglog (en(3:end,1), sigmaC(3:end), '-b');
xlabel('t'); ylabel('\sigma');

subplot (3,2,4)
loglog (en(3:end,1), sigmaE(3:end), '-b');
xlabel('t'); ylabel('\sigma');



subplot (3,2,5)
bar ([2 4 6 8 10 12], barC)
tics('x', [1 5 7 9 13], ['-1.5e-13';'-5e-14';'0';'5e-14';'1.5e-13'])
axis ([1 13])
hold on
xN=1:0.01:13;
x=linspace(-1.5e-13,1.5e-13,1201);
m=muC(end);
s=sigmaC(end);
f=e.^(-0.5*((x-m)/s).^2)/s/sqrt(2*pi);
fN = f/max(f)*330;
plot (xN,fN, '-r');
hold off;

subplot (3,2,6)
bar ([2 4 6 8 10 12 14 16], barE)
tics('x', [1 5 9 13 17], ['-2e-13';'-1e-13';'0';'1e-13';'2e-13'])
axis ([1 17 0 255])
hold on
xN=1:0.01:17;
x=linspace(-2e-13,2e-13,1601);
m=muE(end);
s=sigmaE(end);
f=e.^(-0.5*((x-m)/s).^2)/s/sqrt(2*pi);
fN = f/max(f)*250;
plot (xN,fN, '-r');
hold off;

