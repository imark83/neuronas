clear
cas = load('hairerTestCasimir.txt');
cas = cas';

subplot (1,2,1)
hold on;
for i=1:75
	plot (cas(:,1), cas(:,i+1))
end


muC = zeros (201,1);
for i=1:201
	for j=2:1001
		muC(i) = muC(i) + cas(i,j);
	end
	muC(i) = muC(i) / 1000;
end

sigmaC = zeros (201,1);
for i=1:201
	for j=2:1001
		sigmaC(i) = sigmaC(i) + (cas(i,j) - muC(i))^2;
	end
	sigmaC(i) = sqrt (sigmaC(i) / 1000);
end


plot (cas(:,1), muC, '-k')
plot (cas(:,1), sigmaC, '-k')
plot (cas(:,1), -sigmaC, '-k')
hold off;

title('Error in Casimir');
xlabel('t');
ylabel('error');
axis([0 1e6 -1.5e-13 1.5e-13])

en = load('hairerTestEnergy.txt');
en = en';
en(1,:) = zeros(1,1001);
subplot (1,2,2)
hold on;
for i=1:75
	plot (en(:,1), en(:,i+1))
end


muE = zeros (201,1);
for i=1:201
	for j=2:1001
		muE(i) = muE(i) + en(i,j);
	end
	muE(i) = muE(i) / 1000;
end

sigmaE = zeros (201,1);
for i=1:201
	for j=2:1001
		sigmaE(i) = sigmaE(i) + (en(i,j) - muE(i))^2;
	end
	sigmaE(i) = sqrt (sigmaE(i) / 1000);
end


plot (en(:,1), muE, '-k')
plot (en(:,1), sigmaE, '-k')
plot (en(:,1), -sigmaE, '-k')
hold off;
title('Error in Energy');
xlabel('t');
ylabel('error');

axis([0 1e6 -2e-13 2e-13])

