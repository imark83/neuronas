#ifndef _fun_h
#define _fun_h
#include <stdio.h>
#include "taylorAD.h"

int getNCols ();
void fun (int ncol, int order, double t, double x[ncol], 
		double series[ncol][order+1]);
void printFunctions (FILE *fout, double x[]);
double getEnergy (double x[]);

#endif
