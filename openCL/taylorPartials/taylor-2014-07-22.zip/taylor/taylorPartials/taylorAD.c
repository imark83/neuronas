#include "taylorAD.h"


int  *PREV_ACCUM;
int  *PREV_COEF;
int  *PREV_VI;
int  *PREV_IV;

int  *PREVSTAR_ACCUM;
int  *PREVSTAR_COEF;
int  *PREVSTAR_VI;
int  *PREVSTAR_IV;



/************************************************************************/
void htilde (int n, int i, double *ht, double h[NDER+1][MAX_ORDER+1], int j, int v) {
	if (j == n && i==v) *ht = 0.;
	else *ht = h[v][j];
}
/************************************************************************/

void derInit (int *p_a, int *p_c, int *p_vi, int *p_iv, int *ps_a, int *ps_c, int *ps_vi, int *ps_iv) {
	PREV_ACCUM = p_a;
	PREV_COEF = p_c;
	PREV_VI = p_vi;
	PREV_IV = p_iv;
	PREVSTAR_ACCUM = ps_a;
	PREVSTAR_COEF = ps_c;
	PREVSTAR_VI = ps_vi;
	PREVSTAR_IV = ps_iv;
}


void dp_sumAD (int order, double rop[NDER+1][MAX_ORDER+1],  double op1[NDER+1][MAX_ORDER+1], 
		double op2[NDER+1][MAX_ORDER+1]) {
	int i;
	for(i = 0; i <= NDER; i++) 
		rop[i][order] = op1[i][order] + op2[i][order];
}

void dp_smCAD (int order, double rop[NDER+1][MAX_ORDER+1], double op1[NDER+1][MAX_ORDER+1],
		double op2) {
	int i;
	if (order == 0) 
		rop[0][0] = op1[0][0] + op2;
	else  
		rop[0][order] = op1[0][order];
	for (i=1; i <= NDER; i++) 
		rop[i][order] = op1[i][order];
}

void dp_subAD (int order, double rop[NDER+1][MAX_ORDER+1], double op1[NDER+1][MAX_ORDER+1], 
		double op2[NDER+1][MAX_ORDER+1]) {
	int i;

	for(i = 0; i <= NDER; i++) 
		rop[i][order] = op1[i][order] - op2[i][order];
}

void dp_mulAD (int order, double rop[NDER+1][MAX_ORDER+1], double op1[NDER+1][MAX_ORDER+1],
		double op2[NDER+1][MAX_ORDER+1]) {
	int i, vi, j;
	double sumint;

	for(i=0; i<=NDER; i++) {
		rop[i][order] = 0.;
		for(vi=PREV_ACCUM[i]; vi<PREV_ACCUM[i+1]; vi++) {
			sumint = 0.;
			for(j=0; j<=order; j++)
				sumint += op1[PREV_VI[vi]][order-j]*op2[PREV_IV[vi]][j];
			rop[i][order] += sumint*PREV_COEF[vi];
		}
	}
}

void dp_mlCAD (int order, double rop[NDER+1][MAX_ORDER+1], double op1[NDER+1][MAX_ORDER+1], 
		double op2) {
	int i;
	for(i=0; i<=NDER; i++) 
		rop[i][order] = op1[i][order] * op2;
	
}

void dp_divAD (int order, double rop[NDER+1][MAX_ORDER+1], double op1[NDER+1][MAX_ORDER+1],
		double op2[NDER+1][MAX_ORDER+1]) {

	if (op2[0][0] == 0.) {printf ("Error, divide by 0, bad result\n"); return;}

	int i, j, vi;
	double sumint;
	double ht;

	for (i=0; i<=NDER; i++) {
		rop[i][order] = 0.;
		for(vi=PREV_ACCUM[i]; vi<PREV_ACCUM[i+1]; vi++) {
			sumint = 0.;
			for (j=0; j<=order; j++) {
				htilde (order, i, &ht, rop, order-j, PREV_VI[vi]);
				sumint += ht * op2[PREV_IV[vi]][j];
			}
			rop[i][order] += sumint * PREV_COEF[vi];
		}
		rop[i][order] = (op1[i][order] - rop[i][order]) / op2[0][0];
	}
}

void dp_powAD (int order, double rop[NDER+1][MAX_ORDER+1], double op1[NDER+1][MAX_ORDER+1],
		double op2) {

	if (op1[0][0] == 0.) {printf ("Error, divide by 0, bad result\n"); return;}
	double ht;
	int i, j, vi;

	if (order == 0) {			
		rop[0][0] = pow (op1[0][0], op2);
		for (i=1; i<=NDER; i++) {
			rop[i][0] = 0.;
			for (vi=PREVSTAR_ACCUM[i]; vi<PREVSTAR_ACCUM[i+1]; vi++) {
				htilde (0, i, &ht, rop, 0, PREVSTAR_IV[vi]);
				rop[i][0] += PREVSTAR_COEF[vi]*
	(op2*rop[PREVSTAR_VI[vi]][0]*op1[PREVSTAR_IV[vi]][0] - ht * op1[PREVSTAR_VI[vi]][0]);
			}
			rop[i][0] /= op1[0][0];				
		}
	}
	else {
		double sumint;
		for (i=0; i<=NDER; i++) {
			rop[i][order] = 0.;
			for (j=0; j<=order; j++) {
				sumint = 0.;
				for (vi=PREV_ACCUM[i]; vi<PREV_ACCUM[i+1]; vi++) {
					htilde (order, i, &ht, rop, j, PREV_VI[vi]);
					sumint += PREV_COEF[vi] * ht * op1[PREV_IV[vi]][order-j];
				}
				rop[i][order] += (order*op2 - j*(op2+1.)) * sumint;					
			}
			rop[i][order] /= (order * op1[0][0]);
		}
	}
}

