#include <stdio.h>
#include "taylor.h"


double mu = 0.012277471;
double unomenosmu = 0.987722529;

int event = -1;

double getY (double x, double C) {
	return sqrt (x*x + 2.*(1-mu)/(x+mu) + 2.*mu/(x-1+mu) - C);
}

/*-1.5355000000000001e+00  -1.3926873272597691e+00  3.0320898333517249e+01
-1.5358098731632210e+00  -1.3919999999999990e+00  3.0319395057612251e+01*/
    


int main () {
    
	double x = 9.9399999999999999e-01;
	double C = 2.8564125202098700e+00;
	double T = 1.7065216560157900e+01;
	int nt = 1;


	double x0[12];
	double t0 = 0.;
	double tol = 1e-18;

	x0[0] = x;
	x0[1] = 0.;
	x0[2] = 0.;
	x0[3] = -getY (x, C);
	x0[4] = 1.;
	x0[5] = 0.;
	x0[6] = 0.;
	x0[7] = 0.;
	x0[8] = 0.;
	x0[9] = 0.;
	x0[10] = 0.;
	x0[11] = 1.;
	

	taylor (12, x0, t0, T/nt, nt, tol, stdout);

	return 1;

}
