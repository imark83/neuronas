#include "fun.h"


int NDER = 2;
int nvar = 4;

static int  P_ACCUM[4] = {0,1,3,5};
static int  P_COEF[5] = {1,1,1,1,1};
static int  P_VI[5] = {0,0,1,0,2};
static int  P_IV[5] = {0,1,0,2,0};

static int  PSTAR_ACCUM[4] = {0,1,2,3};
static int  PSTAR_COEF[3] = {0,1,1};
static int  PSTAR_VI[3] = {0,0,0};
static int  PSTAR_IV[3] = {0,1,2};


extern double mu;
extern double unomenosmu;

int getNCols () {
	return 12;
}


void fun (int ncol, int order, double t, double x[ncol], 
		double series[ncol][order+1]) {
	int i, j, k;
	static int unavez = 1;

	if (unavez) {
		derInit (P_ACCUM, P_COEF, P_VI, P_IV, PSTAR_ACCUM, PSTAR_COEF, PSTAR_VI, PSTAR_IV); 
		unavez = 0;
	}
	
	double l[23][NDER+1][order+1];
	double v[4][NDER+1][order+1];		//para las variables
		for (k=0; k<nvar; k++) for (i=0; i<=NDER; i++) 
			v[k][i][0] = x[k+nvar*i];

	for (j=0; j<order; j++) { 
		dp_smCAD (j, l[0], v[0], mu);
		dp_smCAD (j, l[1], v[0], -unomenosmu);
		dp_mulAD (j, l[2], l[0], l[0]);
		dp_mulAD (j, l[3], l[1], l[1]);
		dp_mulAD (j, l[4], v[1], v[1]);
		dp_sumAD (j, l[5], l[2], l[4]);		//r_1^2
		dp_sumAD (j, l[6], l[3], l[4]);		//r_2^2
		dp_powAD (j, l[7], l[5], -1.5);		//r_1^(-3/2)
		dp_powAD (j, l[8], l[6], -1.5);		//r_2^(-3/2)

		dp_mlCAD (j, l[9], l[7], unomenosmu);
		dp_mlCAD (j, l[10], l[8], mu);
		dp_mulAD (j, l[11], l[0], l[9]);
		dp_mulAD (j, l[12], l[1], l[10]);
		dp_mlCAD (j, l[13], v[3], 2);
		dp_sumAD (j, l[14], l[13], v[0]);
		dp_subAD (j, l[15], l[14], l[11]); 
		dp_subAD (j, l[16], l[15], l[12]);	//X'
		dp_mulAD (j, l[17], l[9], v[1]);
		dp_mulAD (j, l[18], l[10], v[1]);
		dp_mlCAD (j, l[19], v[2], -2);
		dp_sumAD (j, l[20], l[19], v[1]);
		dp_subAD (j, l[21], l[20], l[17]);
		dp_subAD (j, l[22], l[21], l[18]);	//Y'

		for (i=0; i<=NDER; i++) {
			v[0][i][j+1] = v[2][i][j] / (j+1.);
			v[1][i][j+1] = v[3][i][j] / (j+1.);
			v[2][i][j+1] = l[16][i][j] / (j+1.);
			v[3][i][j+1] = l[22][i][j] / (j+1.);
		}
	}

	for (k=0; k<nvar; k++) for (i=0; i<=NDER; i++) for (j=0; j<=order; j++)  {
		series[k+i*nvar][j] = v[k][i][j];
	}

}

void printFunctions (FILE *fout, double x[]) {
	fprintf (fout, "  %.16le", getEnergy (x));
}


double getEnergy (double x[]) {
	double r1 = sqrt ((x[0]+mu)*(x[0]+mu) + x[1]*x[1]);
	double r2 = sqrt ((x[0]-unomenosmu)*(x[0]-unomenosmu) + x[1]*x[1]);


	return x[0]*x[0] + x[1]*x[1] + 2.*unomenosmu/r1 + 2*mu/r2 -x[2]*x[2] - x[3]*x[3];

}

