#include "taylorAD.h"


void dp_sumAD (int order, double rop[order+1], double op1[order+1], 
		double op2[order+1]) {
	rop[order] = op1[order] + op2[order];
}

void dp_subAD (int order, double rop[order+1], double op1[order+1], 
		double op2[order+1]) {
	rop[order] = op1[order] - op2[order];
}

void dp_mulAD (int order, double rop[order+1], double op1[order+1], 
		double op2[order+1]) {
	int i;
	rop[order] = 0.;
	for (i=0; i<=order; i++) rop[order] += op1[i] * op2[order-i];
}


void dp_divAD (int order, double rop[order+1], double op1[order+1],
		double op2[order+1]) {
//NOT CHECKED
	if (op2[0] == 0.) {printf ("Error, divide by 0, bad result\n"); return;}

	int i;
	rop[order] = 0.;
	for (i=1; i<=order; i++) rop[order] += op2[i] * rop[order-i];
	rop[order] = (op1[order] - rop[order]) / op2[0];
}

void dp_powAD (int order, double rop[order+1], double op1[order+1],
		double op2) {
	if (op1[0] == 0.) {printf ("Error, divide by 0, bad result\n"); return;}
	if (order == 0) rop [0] = pow (op1[0], op2);
	else {
		int i;
		rop[order] = 0.;
		for (i=0; i<order; i++) 
			rop[order] += (order*op2 - i*(op2+1)) * 
				op1[order-i] * rop[i];
		rop[order] = rop[order] / op1[0] / order;


	}

}

