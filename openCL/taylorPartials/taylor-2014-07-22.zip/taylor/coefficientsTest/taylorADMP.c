#include "taylorADMP.h"


void mp_sumAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1], 
		mpfr_t op2[order+1]) {
	mpfr_add (rop[order], op1[order], op2[order], GMP_RNDN);
}

void mp_subAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1], 
		mpfr_t op2[order+1]) {
	mpfr_sub (rop[order], op1[order], op2[order], GMP_RNDN);
}

void mp_mulAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1], 
		mpfr_t op2[order+1]) {
	int i;
	mpfr_t aux; mpfr_init (aux);
	mpfr_set_si (rop[order], 0, GMP_RNDN);
	for (i=0; i<=order; i++) {
		mpfr_mul (aux, op1[i], op2[order - i], GMP_RNDN);
		mpfr_add (rop[order], rop[order], aux, GMP_RNDN);
	}
	mpfr_clear (aux);
}

void mp_powAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1],	
		char *cOp2) {
	if (mpfr_cmp_si (op1[0], 0) == 0){
		printf ("Error, divide by 0, bad result\n");
		return;
	}
	mpfr_t op2; mpfr_init (op2); mpfr_set_str (op2, cOp2, 10, GMP_RNDN);
	if (order == 0) mpfr_pow (rop[0], op1[0], op2, GMP_RNDN);
	else {
		int i;
		mpfr_t aux1; mpfr_init (aux1);
		mpfr_t aux2; mpfr_init (aux2);
		mpfr_set_si (rop[order], 0, GMP_RNDN);
		for (i=0; i<order; i++) {
			mpfr_mul_si (aux1, op2, order, GMP_RNDN);
			mpfr_add_si (aux2, op2, 1, GMP_RNDN);
			mpfr_mul_si (aux2, aux2, i, GMP_RNDN);
			mpfr_sub (aux1, aux1, aux2, GMP_RNDN);
			mpfr_mul (aux1, aux1, op1[order-i], GMP_RNDN);
			mpfr_mul (aux1, aux1, rop[i], GMP_RNDN);
			mpfr_add (rop[order], rop[order], aux1, GMP_RNDN);
		}
		mpfr_div (rop[order], rop[order], op1[0], GMP_RNDN);
		mpfr_div_si (rop[order], rop[order], order, GMP_RNDN);

		mpfr_clear (aux1); mpfr_clear (aux2); mpfr_clear (op2);
	}
}

