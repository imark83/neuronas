#include "funMP.h"


void mp_fun (int nvar, int order, mpfr_t t, mpfr_t x[nvar], 
		mpfr_t series[nvar][order+1]) {

	int i, j;
	for (i=0; i<nvar; i++) mpfr_set (series[i][0], x[i], GMP_RNDN);

	int nl = 6;
	mpfr_t l[nl][order];
	for (i=0; i<nl; i++) for (j=0; j<order; j++) mpfr_init (l[i][j]);

	for (i=0; i<order; i++) {
		mp_mulAD (i, l[0], series[0], series[0]);
		mp_mulAD (i, l[1], series[1], series[1]);
		mp_sumAD (i, l[2], l[0], l[1]);
		mp_powAD (i, l[3], l[2], "-1.5");
		mp_mulAD (i, l[4], series[0], l[3]);
		mp_mulAD (i, l[5], series[1], l[3]);
			mpfr_mul_si (l[4][i], l[4][i], -1, GMP_RNDN);
			mpfr_mul_si (l[5][i], l[5][i], -1, GMP_RNDN);

		mpfr_set (series[0][i+1], series[2][i], GMP_RNDN);
		mpfr_set (series[1][i+1], series[3][i], GMP_RNDN);
		mpfr_set (series[2][i+1], l[4][i], GMP_RNDN);
		mpfr_set (series[3][i+1], l[5][i], GMP_RNDN);
		mpfr_div_si (series[0][i+1], series[0][i+1], i+1, GMP_RNDN);
		mpfr_div_si (series[1][i+1], series[1][i+1], i+1, GMP_RNDN);
		mpfr_div_si (series[2][i+1], series[2][i+1], i+1, GMP_RNDN);
		mpfr_div_si (series[3][i+1], series[3][i+1], i+1, GMP_RNDN);
	}

	for (i=0; i<nl; i++) for (j=0; j<order; j++) mpfr_clear (l[i][j]);

}

