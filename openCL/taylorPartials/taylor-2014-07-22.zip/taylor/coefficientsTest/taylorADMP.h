#ifndef _taylorAD_h
#define _taylorAD_h
#include <stdio.h>
#include <mpfr.h>
void mp_sumAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1], 
		mpfr_t op2[order+1]);
void mp_subAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1], 
		mpfr_t op2[order+1]);
void mp_mulAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1], 
		mpfr_t op2[order+1]);
void mp_powAD (int order, mpfr_t rop[order+1], mpfr_t op1[order+1],	
		char *cOp2);

#endif
