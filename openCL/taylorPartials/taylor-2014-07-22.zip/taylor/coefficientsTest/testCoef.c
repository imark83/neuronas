#include <stdio.h>
#include <mpfr.h>
#include "fun.h"
#include "funMP.h"

int digits = 100;

int main () {
	int precision = (int) ceil (digits * 3.321928);
	mpfr_set_default_prec (precision);
	int nvar = 4, order = 1000, i, j;
	double t = 0., x[nvar], series[nvar][order+1];
	mpfr_t aux, mpT, mpX[nvar], mpSeries[nvar][order+1], 	
		error[nvar][order+1], errorGlobal[order+1];
	
	mpfr_init (mpT); mpfr_init (aux);
	for (i=0; i<nvar; i++) {
		for (j=0; j<=order; j++) mpfr_init (mpSeries[i][j]);
		mpfr_init (mpX[i]);
	}
	for (i=0; i<nvar; i++) for (j=0; j<=order; j++) 
		mpfr_init (error[i][j]);
	for (j=0; j<=order; j++) {
		mpfr_init (errorGlobal[j]);
		mpfr_set_si (errorGlobal[j], -1, GMP_RNDN);
	}

	t = 0.;     mpfr_set_str (mpT, "0.", 10, GMP_RNDN);
	x[0] = -7.5416542254921426e-01; 
	mpfr_set_str (mpX[0], "-7.5416542254921426e-01", 10, GMP_RNDN);
	x[1] = -7.1309446398780840e-01; 
	mpfr_set_str (mpX[1], "-7.1309446398780840e-01", 10, GMP_RNDN);
	x[2] = 9.6205489887361118e-01; 
	mpfr_set_str (mpX[2], "9.6205489887361118e-01", 10, GMP_RNDN);
	x[3] = -3.7268773633459817e-02; 
	mpfr_set_str (mpX[3], "-3.7268773633459817e-02", 10, GMP_RNDN);

	fun (nvar, order, t, x, series);
	mp_fun (nvar, order, mpT, mpX, mpSeries);

	for (i=0; i<nvar; i++) for (j=0; j<=order; j++) {
		mpfr_sub_d (error[i][j], mpSeries[i][j], 
			series[i][j], GMP_RNDN);
		mpfr_out_str (stdout, 10, 16, error[i][j], GMP_RNDN);
		mpfr_div (error[i][j], error[i][j], 
			mpSeries[i][j], GMP_RNDN);
		printf ("    ");
		mpfr_out_str (stdout, 10, 16, error[i][j], GMP_RNDN);
		printf ("    ");
		mpfr_out_str (stdout, 10, 20, mpSeries[i][j], GMP_RNDN);
		printf ("    %.16le\n", series [i][j]);
		
	}

	printf ("--------------------------\n");

	FILE *fout = fopen ("errorCoef.txt", "w");

	for (j=0; j<=order; j++) {
		mpfr_abs (errorGlobal[j], error[0][j], GMP_RNDN);
		for (i=1; i<nvar; i++) {
			mpfr_abs (aux, error[i][j], GMP_RNDN);
			if (mpfr_greater_p (aux, errorGlobal[j]))
				mpfr_set (errorGlobal[j], aux, GMP_RNDN);
		}
		mpfr_out_str (fout, 10, 16, errorGlobal[j], GMP_RNDN);
		fprintf (fout, "\n");
	}
	

	fclose (fout);
	return 0;
}
