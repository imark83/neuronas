#include "taylor.h"

int kahan = 0;
int fac = 1;
int main () {
	int nvar = 1;

	double x[nvar];
	double t0 = 1.;
	double tf = 10.;
	double tol = 1e-16;
	x[0] = 1.31037069710445;

	FILE *fout = stdout; //fopen ("kepler1.txt", "w");

	taylor (nvar, x, t0, tf, tol, fout);

	//fclose (fout);
	
	return 1;
}

