#include "fun.h"


void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	double l[6][order];

	for (i=0; i<order; i++) {
		dp_powAD (i, l[0], series[0], -0.5);
		
		series[0][i+1] = l[0][i]/(i+1);
		int j;
		
	}
/*
static int unavez = 1;
if (unavez)
	for (i=0; i<6; i++) {
		printf ("%.16le  ", series[0][i]);
		printf ("%.16le  ", series[1][i]);
		printf ("%.16le  ", series[2][i]);
		printf ("%.16le  ", series[3][i]);
		printf ("\n");
	}
unavez = 0;	
*/

}

void printFunctions (FILE *fout, double x[]) {
//	fprintf (fout, "  %.16le  %.16le", getSinCos (x), getSinDen (x));
}

