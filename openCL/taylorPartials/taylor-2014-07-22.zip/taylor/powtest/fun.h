#ifndef _fun_h
#define _fun_h
#include <stdio.h>
#include "taylorAD.h"
void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order]);
void printFunctions (FILE *fout, double x[]);

#endif
