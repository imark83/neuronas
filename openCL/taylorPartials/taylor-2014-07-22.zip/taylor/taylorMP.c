#include "taylorMP.h"

extern int digits;
extern int event;
extern FILE *fpoinc;
extern back;

int count;
void mp_taylor (int nvar, mpfr_t x[nvar], mpfr_t t0, mpfr_t delta, int nt, 
		mpfr_t tol, FILE *fout) {
	count = 0;
	int nsteps = 0;
	int denseStep = 0;
	int i, j;
	int order = getOrder (tol);
	int precision = (int) ceil (digits * 3.321928);
	mpfr_set_default_prec (precision);


	mpfr_t series[nvar][order+1], xx[nvar], t, tt, tf, dt, step, aux;
	mpfr_init (dt); // distancia para evaluar la serie
	for (i=0; i<nvar; i++) mpfr_init (xx[i]); //puntos para salida densa
	mpfr_init (t);  //posicion de la integracion
	mpfr_init (tt);  //posicion de la salida densa
	mpfr_init (step);  //paso
	for (i=0; i<nvar; i++) 
		for (j=0; j<=order; j++) 
			mpfr_init (series[i][j]);   //para guardar la serie de taylor

/******************************************/
//*****POINCARE
	mpfr_t criterion, pCut[nvar], tCut, y_old;
	if (event >=0) {
		mpfr_init (criterion);
		mpfr_init (tCut);
		for (i=0; i<nvar; i++) mpfr_init (pCut[i]);
	mpfr_init (y_old);
	}
//*****
/******************************************/
	

	mpfr_set (t, t0, MPFR_RNDN); 
	mpfr_set (tt, t0, MPFR_RNDN);
	mpfr_set_si (dt, 0, MPFR_RNDN);



	while (denseStep < nt+1) {
		if (back) mp_funBack (nvar, order, t, x, series); 
		else mp_fun (nvar, order, t, x, series); 
		getStep (step, nvar, order, series, tol);
		nsteps++;




	/******************************************/
	//*****SALIDA DENSA
		while ((mpfr_cmp(step, dt) > 0) && denseStep < nt+1) {
			horner (nvar, order, dt, series, xx);
			if (fout != NULL) { 
				mpfr_out_str (fout, 10, digits, tt, MPFR_RNDN);
	  			for (i=0; i<nvar; i++) {	
					fprintf (fout, "  ");
					mpfr_out_str (fout, 10, digits, xx[i], 
							MPFR_RNDN);
				}
				printFunctions (fout, xx, digits);
				fprintf (fout, "\n");
			}
			mpfr_add (dt, dt, delta, MPFR_RNDN);
			mpfr_add (tt, tt, delta, MPFR_RNDN);
			denseStep++;
		} 
	//*****
	/******************************************/


	/******************************************/
	//*****POINCARE
		if (event >=0) mpfr_set (y_old, x[event], MPFR_RNDN);

		horner (nvar, order, step, series, x);

		if (event >=0) {
			mpfr_mul (criterion, y_old, x[event], MPFR_RNDN);
			if (mpfr_cmp_si (criterion, 0) < 0) {
				poincare (nvar, order, step, series, event, tol, pCut, tCut); 
				mpfr_add (tCut, t, tCut, MPFR_RNDN);
				mpfr_out_str (fpoinc, 10, digits, tCut, MPFR_RNDN);
				for (i=0; i<nvar; i++) {
					fprintf (fpoinc , "  ");
					mpfr_out_str (fpoinc, 10, digits, pCut[i], 
							MPFR_RNDN);
				}
				fprintf (fpoinc, "\n");
				if (count==1) return;
				count++;
			}
		}

	//*****
	/******************************************/

		mpfr_add (t, t, step, MPFR_RNDN);
		mpfr_sub (dt, dt, step, MPFR_RNDN);

	}
	
	for (i=0; i<nvar; i++) mpfr_set (x[i], xx[i], MPFR_RNDN);
	//printf ("nsteps = %i\n", nsteps);

/******************************************/
//*****LIMPIEZA
	mpfr_clear (dt); // distancia para evaluar la serie
	for (i=0; i<nvar; i++) mpfr_clear (xx[i]); //puntos para salida densa
	mpfr_clear (t);  //posicion de la integracion
	mpfr_clear (tt);  //posicion de la salida densa
	mpfr_clear (step);  //paso
	for (i=0; i<nvar; i++) 
		for (j=0; j<=order; j++) 
			mpfr_clear (series[i][j]);  //serie
	if (event >=0) {
		mpfr_clear (criterion);
		mpfr_clear (tCut);
		for (i=0; i<nvar; i++) mpfr_init (pCut[i]);
		mpfr_init (y_old);
	}
//*****
/******************************************/

}

void poincare (int nvar, int order, mpfr_t step, mpfr_t series[nvar][order+1], 
		int event, mpfr_t tol, mpfr_t rop[nvar], mpfr_t h) {


	int i;
	/* p = p(h).  p(h_L)*p(h_R) < 0   search h so that p(h) == 0  biseccion*/
	mpfr_t h_L, h_R, h_M, p_L, p_R, p_M, x[nvar], error, criterion;

	mpfr_init (h_L); // h izquierdo
	mpfr_init (h_R); // h derecho
	mpfr_init (h_M); // h central
	mpfr_init (p_L); // evaluacion de p(h_L)
	mpfr_init (p_R); // evaluacion de p(h_R)
	mpfr_init (p_M); // evaluacion de p(h_M)
	for (i=0; i<nvar; i++) mpfr_init (x[i]); // almacen de evaluacion de la serie completa
	mpfr_init (error); //error en cada paso


	mpfr_set_si(h_L, 0, MPFR_RNDN);  // h izquierdo empieza en cero
	mpfr_set (h_R, step, MPFR_RNDN); // h derech empieza al final del paso
	mpfr_init (criterion); // comprueba si hay cambio de signo

	
//	horner (nvar, order, h_R, series, x);  ???????
	do {
		horner (nvar, order, h_L, series, x);  // x(h_L)
		mpfr_set (p_L, x[event], MPFR_RNDN); // p(h_L) = x(h_L) correspondiente

		horner (nvar, order, h_R, series, x); // x(h_R)
		mpfr_set (p_R, x[event], MPFR_RNDN); // p(h_R) = x(h_R) correspondiente

		//h_M = (h_L + h_R)/2.;
		mpfr_add (h_M, h_L, h_R, MPFR_RNDN); mpfr_div_si (h_M, h_M, 2, MPFR_RNDN);

		horner (nvar, order, h_M, series, x); // x(h_M)
		mpfr_set (p_M, x[event], MPFR_RNDN); // p(h_M) = x(h_M) correspondiente

		mpfr_mul (criterion, p_M, p_L, MPFR_RNDN); //vemos si el cero esta entre h_L y h_M
		if (mpfr_cmp_si(criterion, 0) < 0) 
			mpfr_set (h_R, h_M, MPFR_RNDN);
		else 					// si no, esta entre h_M y h_R
			mpfr_set (h_L, h_M, MPFR_RNDN);

		/*mpfr_set (err, p_M, MPFR_RNDN);
		mpfr_abs (criterion, p_M, MPFR_RNDN);  ????????? */
		mpfr_abs (error, p_M, MPFR_RNDN);  //aproximacion del error
		
	} while (mpfr_cmp (error, tol) > 0);

	horner (nvar, order, h_M, series, rop);  //se guarda la evaluacion en el punto medio como punto de poincare
	mpfr_set (h, h_M, MPFR_RNDN);

	/*  LIMPIEZA  C*/
	mpfr_clear (h_L);
	mpfr_clear (h_R);
	mpfr_clear (h_M);
	mpfr_clear (p_L);
	mpfr_clear (p_M);
	mpfr_clear (p_R);
	mpfr_clear (criterion);
	for (i=0; i<nvar; i++) mpfr_clear (x[i]);
	mpfr_clear (error);
}



void mp_taylor_old (int nvar, mpfr_t x[nvar], int nlt, mpfr_t lt[nlt], 
		mpfr_t tol, FILE *fout) {

	int nsteps = 0, i, j;
	int order = getOrder (tol), precision = (int) ceil (digits * 3.321928);
	mpfr_set_default_prec (precision);
	mpfr_t series[nvar][order+1];
	mpfr_t t, tOld; 
	mpfr_t step; 

	mpfr_t dt, dx[nvar];
	mpfr_init (dt); for (i=0; i<nvar; i++) mpfr_init (dx[i]);

	mpfr_init (t); mpfr_init (step); mpfr_init (tOld); 
	for (i=0; i<nvar; i++) for (j=0; j<=order; j++) 
		mpfr_init (series[i][j]);

	mpfr_set (t, lt[0], MPFR_RNDN); 

	mpfr_out_str (fout, 10, digits, t, MPFR_RNDN);
	for (i=0; i<nvar; i++) {
		fprintf (fout, "  ");
		mpfr_out_str (fout, 10, digits, x[i], MPFR_RNDN);
	}
	printFunctions (fout, x, digits);
	fprintf (fout, "\n");

	j = 1;
	while (mpfr_less_p (t, lt[nlt-1])) {
		mp_fun (nvar, order, t, x, series);

		getStep (step, nvar, order, series, tol);
		nsteps++;
		mpfr_set (tOld, t, MPFR_RNDN);
		mpfr_add (t, t, step, MPFR_RNDN);
		horner (nvar, order, step, series, x);
		

		while (mpfr_less_p (lt[j], t)) {
			mpfr_sub (dt, lt[j], tOld, MPFR_RNDN);
			horner (nvar, order, dt, series, dx); 
			mpfr_out_str (fout, 10, digits, lt[j], MPFR_RNDN);
  			for (i=0; i<nvar; i++) {
				fprintf (fout, "  ");
				mpfr_out_str (fout, 10, digits, dx[i], 
						MPFR_RNDN);
			}
			printFunctions (fout, x, digits);
			fprintf (fout, "\n");
			j++;
		}
	}
	printf ("nsteps = %i\n", nsteps);

}

int getOrder (mpfr_t tol) {
	mpfr_t logTol; mpfr_init (logTol);
	mpfr_log (logTol, tol, GMP_RNDN);
	double dTol = mpfr_get_d (logTol, GMP_RNDN);
	return ceil (-(dTol)/2.);	
}
void getStep (mpfr_t rop, int nvar, int order, mpfr_t series[nvar][order+1], 
		mpfr_t tol) {
	int i; 
	mpfr_t n1, n2;
	mpfr_t x1[nvar], x2[nvar];
	mpfr_init (n1); mpfr_init (n2);	
	mpfr_t h1, h2, e1, e2; 
	mpfr_init (h1); mpfr_init (h2); mpfr_init (e1); mpfr_init (e2);

	for (i=0; i<nvar; i++) {mpfr_init (x1[i]); mpfr_init (x2[i]);}
	
	for (i=0; i<nvar; i++) {
		mpfr_set (x1[i], series[i][order], MPFR_RNDN);
		mpfr_set (x2[i], series[i][order-1], MPFR_RNDN);
	}
	normInf (n1, nvar, x1); normInf (n2, nvar, x2);

	
	mpfr_set_str (e1, "1.", 10, MPFR_RNDN); 
		mpfr_set_str (e2, "1.", 10, MPFR_RNDN);
	mpfr_div_si (e1, e1, order, MPFR_RNDN); 
		mpfr_div_si (e2, e2, order-1, MPFR_RNDN);
	mpfr_div (h1, tol, n1, MPFR_RNDN);
	mpfr_div (h2, tol, n2, MPFR_RNDN);
	mpfr_pow (h1, h1, e1, MPFR_RNDN); mpfr_pow (h2, h2, e2, MPFR_RNDN);
	//h1 = pow ((tol/n1), 1./order);
	//h2 = pow ((tol/n2), 1./(order-1));
	if (mpfr_less_p (h1, h2)) mpfr_set (rop, h1, MPFR_RNDN);
	else mpfr_set (rop, h2, MPFR_RNDN);
	mpfr_clear (n1);
	mpfr_clear (n2);
	mpfr_clear (h1);
	mpfr_clear (h2);
	mpfr_clear (e1);
	mpfr_clear (e2);
	for (i=0; i<nvar; i++) {
		mpfr_clear (x1[i]);
		mpfr_clear (x2[i]);
	}
}

void horner (int nvar, int order, mpfr_t h, mpfr_t series[nvar][order+1], 
		mpfr_t rop[nvar]) {
	int i, j;
	
	for (i=0; i<nvar; i++) 
		mpfr_set (rop[i], series[i][order], MPFR_RNDN);;
	for (i=order-1; i>=0; i--)
		for (j=0; j<nvar; j++) {
			mpfr_mul (rop[j], rop[j], h, MPFR_RNDN);
			mpfr_add (rop[j], rop[j], series[j][i], MPFR_RNDN);
			
		}
}

void normInf (mpfr_t rop, int nvar, mpfr_t x[nvar]) {
	mpfr_set_si (rop, 0, MPFR_RNDN);
	mpfr_t aux; mpfr_init (aux);
	int i;
	for (i=0; i<nvar; i++) {
		mpfr_abs (aux, x[i], MPFR_RNDN);
		if (mpfr_greater_p (aux, rop)) mpfr_set (rop, aux, MPFR_RNDN);
	}
	mpfr_clear (aux);

}
