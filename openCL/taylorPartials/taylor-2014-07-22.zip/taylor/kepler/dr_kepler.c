#include "taylor.h"

int kahan = 1;
int fac = 350;
int main () {
	int nvar = 4;

	double x[nvar];
	double t0 = 0.;
	double pi = 3.14159265358979323;
	double tf = 100000.;
	int nt = 1000;
	double tol = 1e-18;
	double e = 0.7;
	x[0] = 1.-e;
	x[1] = 0.;
	x[2] = 0.;
	x[3] = sqrt ((1.+e)/(1.-e));

	FILE *fout = fopen ("kepler1.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	fclose (fout);
	
	return 1;
}

