#include "fun.h"


void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	double l[6][order];

	for (i=0; i<order; i++) {
		dp_mulAD (i, l[0], series[0], series[0]);	
		dp_mulAD (i, l[1], series[1], series[1]);
		dp_sumAD (i, l[2], l[0], l[1]);
		dp_powAD (i, l[3], l[2], -3./2.);
		dp_mulAD (i, l[4], series[0], l[3]);
		dp_mulAD (i, l[5], series[1], l[3]);
			l[4][i] *= -1;
			l[5][i] *= -1;

		series[0][i+1] = series[2][i]/(i+1.);
		series[1][i+1] = series[3][i]/(i+1.);
		series[2][i+1] = l[4][i]/(i+1.);
		series[3][i+1] = l[5][i]/(i+1.);
	
	}


}

void printFunctions (FILE *fout, double x[]) {
	fprintf (fout, "  %.16le", getEnergy (x));
}


double getEnergy (double x[]) {
	double K, V;
	K = (x[2]*x[2] + x[3]*x[3])/2.;
	V = -1./sqrt (x[0]*x[0] + x[1]*x[1]);

	return K + V;


}

