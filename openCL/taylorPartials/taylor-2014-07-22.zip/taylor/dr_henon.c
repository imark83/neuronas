#include "taylor.h"

int kahan = 1;
int fac = 1;
int event = -1;
FILE *fpoinc;

double getX (double y, double H);

int main () {
	int nvar = 4;

	double x[nvar];
	double t0 = 0.;
	double tf = 2.4916990924559233e+01;
	int nt = 100;
	double tol = 1e-25;
	x[0] = 0.;
	x[1] = 9.3520436787173686e-02;
	x[2] = getX (x[1], 1.180000e-01);
	x[3] = 0.;

   
	fpoinc = stdout;


	FILE *fout = fopen ("hh55.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt+1, tol, fout);

	fclose (fout);
	
	return 1;
}

double getX (double y, double H) {
	return sqrt (2*H - y*y + 2./3.*y*y*y);
}
