#include "taylorMP.h"
int digits = 32;

int main () {
	char sfout[] = "keplerSol.txt";
	int nvar = 4;
	int i, nt, precision = (int) ceil (digits * 3.321928);
	mpfr_t x[nvar]; for (i=0; i<nvar; i++) mpfr_init2 (x[i], precision);
	mpfr_t tol; 
	mpfr_init2 (tol, precision);
	mpfr_t delta;
	mpfr_init2 (delta, precision);
	mpfr_t t0;
	mpfr_init2 (t0, precision);


// SET INITIAL CONDITIONS
	mpfr_set_str (t0, "0.", 10, GMP_RNDN);
	mpfr_set_str (delta, "10000.", 10, GMP_RNDN);
	nt = 1000;

	mpfr_set_str (x[0], "0.3", 10, GMP_RNDN);
	mpfr_set_str (x[1], "0.", 10, GMP_RNDN);
	mpfr_set_str (x[2], "0.", 10, GMP_RNDN);
	mpfr_set_str (x[3], "2.3804761428476166659997999371224218", 10, GMP_RNDN);
	mpfr_set_str (tol, "1e-35", 10, GMP_RNDN);

	FILE *fout = fopen (sfout, "w");
	mp_taylor (nvar, x, t0, delta, nt, tol, fout);
	fclose (fout);

	return 0;

}

