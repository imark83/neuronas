#include "funMP.h"

mpfr_t k2;

void mp_fun (int nvar, int order, mpfr_t t, mpfr_t x[nvar], 
		mpfr_t series[nvar][order+1]) {

	int i, j;
	static int unavez = 1;
	if (unavez) {
		mpfr_init (k2);
		mpfr_set_str (k2, "0.25", 10, GMP_RNDN);
	}
	unavez = 0;
	for (i=0; i<nvar; i++) mpfr_set (series[i][0], x[i], GMP_RNDN);

	mpfr_t l[3][order];
	for (i=0; i<3; i++) for (j=0; j<order; j++) mpfr_init (l[i][j]);

	for (i=0; i<order; i++) {
		mp_mulAD (i, l[0], series[1], series[2]);
		mp_mulAD (i, l[1], series[0], series[2]);
			mpfr_mul_si (l[1][i], l[1][i], -1, GMP_RNDN);
		mp_mulAD (i, l[2], series[0], series[1]);
			mpfr_mul (l[2][i], l[2][i], k2, GMP_RNDN); 
			mpfr_mul_si (l[2][i], l[2][i], -1, GMP_RNDN);

		mpfr_set (series[0][i+1], l[0][i], GMP_RNDN);
		mpfr_set (series[1][i+1], l[1][i], GMP_RNDN);
		mpfr_set (series[2][i+1], l[2][i], GMP_RNDN);
		mpfr_div_si (series[0][i+1], series[0][i+1], i+1, GMP_RNDN);
		mpfr_div_si (series[1][i+1], series[1][i+1], i+1, GMP_RNDN);
		mpfr_div_si (series[2][i+1], series[2][i+1], i+1, GMP_RNDN);
	}

	for (i=0; i<3; i++) for (j=0; j<order; j++) mpfr_clear (l[i][j]);

}

void printFunctions (FILE *fout, mpfr_t x[], int digits) {
	mpfr_t sincos, sinden; 
	mpfr_init (sincos); mpfr_init (sinden);
	getSinCos (sincos, x);
	getSinDen (sinden, x);
	fprintf (fout, "  ");
	mpfr_out_str (fout, 10, digits, sincos, GMP_RNDN);
	fprintf (fout, "  ");	
	mpfr_out_str (fout, 10, digits, sinden, GMP_RNDN);
	mpfr_clear (sincos);
	mpfr_clear (sinden);
}

void getSinCos (mpfr_t rop, mpfr_t x[]) {
	mpfr_t aux; mpfr_init (aux);
	mpfr_set_str (rop, "0.", 10, GMP_RNDN);
	mpfr_mul (aux, x[0], x[0], GMP_RNDN);
	mpfr_add (rop, rop, aux, GMP_RNDN);
	mpfr_mul (aux, x[1], x[1], GMP_RNDN);
	mpfr_add (rop, rop, aux, GMP_RNDN);

	mpfr_clear (aux);
}
void getSinDen (mpfr_t rop, mpfr_t x[]) {
	mpfr_t aux; mpfr_init (aux);
	mpfr_set_str (rop, "0.", 10, GMP_RNDN);
	mpfr_mul (aux, x[0], x[0], GMP_RNDN);
	mpfr_mul (aux, aux, k2, GMP_RNDN);
	mpfr_add (rop, rop, aux, GMP_RNDN);
	mpfr_mul (aux, x[2], x[2], GMP_RNDN);
	mpfr_add (rop, rop, aux, GMP_RNDN);

	mpfr_clear (aux);
}


