clear

j1 = load ('jacobi1.txt');
j2 = load ('jacobi2.txt');
j1Sol = load ('jacobi1Sol.txt');
j2Sol = load ('jacobi2Sol.txt');

n = size(j1)(1);
err1(:,1) = j1(:,1);
for i=1:n
	err1(i,2) = norm (j1(i,2) - j1Sol(i,2)) + ...
		norm (j1(i,2) - j1Sol(i,2)) + norm (j1(i,2) - j1Sol(i,2));
	err1(i,3) = norm (j1(i,5) - j1Sol (i,5));
	err1(i,4) = norm (j1(i,6) - j1Sol (i,6));
end

err2(:,1) = j2(:,1);
for i=1:n
	err2(i,2) = norm (j2(i,2) - j2Sol(i,2)) + ...
		norm (j2(i,2) - j2Sol(i,2)) + norm (j2(i,2) - j2Sol(i,2));
	err2(i,3) = norm (j2(i,5) - j2Sol (i,5));
	err2(i,4) = norm (j2(i,6) - j2Sol (i,6));
end

subplot (3,1,1);
semilogy (err1(:,1), err1(:,2), '-b;nothing;')
hold on;
semilogy (err2(:,1), err2(:,2), '-r;kahan;')
hold off;
legend('nothing', 'kahan', "location", "southeast");

subplot (3,1,2);
semilogy (err1(:,1), err1(:,3), '-b;nothing;')
hold on;
semilogy (err2(:,1), err2(:,3), '-r;kahan;')
hold off;
legend('nothing', 'kahan', "location", "southeast");

subplot (3,1,3);
semilogy (err1(:,1), err1(:,4), '-b;nothing;')
hold on;
semilogy (err2(:,1), err2(:,4), '-r;kahan;')
hold off;
legend('nothing', 'kahan', "location", "southeast");


