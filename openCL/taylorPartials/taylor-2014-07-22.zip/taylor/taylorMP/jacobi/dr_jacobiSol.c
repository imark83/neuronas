#include "taylorMP.h"
int digits = 32;

int main () {
	double trash;
	int nvar = 3;
	int i, precision = (int) ceil (digits * 3.321928);
	mpfr_t x[nvar]; for (i=0; i<nvar; i++) mpfr_init2 (x[i], precision);
	mpfr_t t0, tf, tol; 
	mpfr_init2 (tol, precision);


// COUTN NUMBER OF MEMBERS IN DENSE OUTPUT
	int nlt = 0;
	FILE *finp = fopen ("jacobi2.txt", "r");
	do {
		fscanf (finp, "%le  %le  %le  %le  %le  %le\n", 
			&trash, &trash, &trash, &trash, &trash, &trash);
		nlt++;
	} while (!feof (finp));
	fclose (finp);



// READ POINTS IN DENSE OUTPUT
	mpfr_t lt[nlt]; for (i=0; i<nlt; i++) mpfr_init2 (lt[i], precision);

	finp = fopen ("jacobi2.txt", "r");
	for (i=0; i<nlt; i++) {
		mpfr_inp_str (lt[i], finp, 10, GMP_RNDN);
		fscanf (finp, "  %le  %le  %le  %le  %le\n", 
			&trash, &trash, &trash, &trash, &trash);
	} 
	fclose (finp);


// SET INITIAL CONDITIONS
	mpfr_set_str (x[0], "0.", 10, GMP_RNDN);
	mpfr_set_str (x[1], "1.", 10, GMP_RNDN);
	mpfr_set_str (x[2], "1.", 10, GMP_RNDN);
	mpfr_set_str (tol, "1e-35", 10, GMP_RNDN);


// CALL THE INTEGRATOR
	FILE *fout = fopen ("jacobi2Sol.txt", "w");
	mp_taylor (nvar, x, nlt, lt, tol, fout);
	fclose (fout);

	return 0;

}

