clear

kep1 = load ('kepler0.txt');
kep2 = load ('kepler1.txt');
kepSol = load ('keplerSol.txt');

n = size(kep1)(1);
err1(:,1) = kep1(:,1);
for i=1:n
	err1(i,2) = norm (kep1(i,2:5) - kepSol(i,2:5))/norm(kepSol (i,2:5)); 
	err1(i,3) = norm (kep1(i,6) - kep1 (1,6));
end

err2(:,1) = kep2(:,1);


for i=1:n
	err2(i,2) = norm (kep2(i,2:5) - kepSol(i,2:5))/norm(kepSol (i,2:5)); 
	err2(i,3) = norm (kep2(i,6) - kep2 (1,6));
end



subplot (2,1,1);
loglog (err1(1:2:end,1), err1(1:2:end,2), '-b;nothing;')
hold on;
loglog (err2(1:2:end,1), err2(1:2:end,2), '-r;kahan;')
hold off;
legend('nothing', 'kahan', "location", "southeast");
title ('Error in position, Kepler e=0.5');
axis ([1e3,1e5,1e-12,1e-6]);

subplot (2,1,2);
loglog (err1(:,1), err1(:,3), '-b;nothing;')
hold on;
loglog (err2(:,1), err2(:,3), '-r;kahan;')
hold off;
legend('nothing', 'kahan',  "location", "southeast");
title ('Error in Energy, Kepler e=0.5');
axis ([1e3,1e5,1e-16,1e-12]);

