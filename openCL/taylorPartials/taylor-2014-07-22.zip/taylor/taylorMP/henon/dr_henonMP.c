#include "taylorMP.h"

int kahan = 1;
int fac = 1;
int event = -1;
int digits = 30;
FILE *fpoinc;

int main () {
	int nvar = 4, i, precision = (int) ceil (digits * 3.321928);

	mpfr_t x[nvar]; for (i=0; i<nvar; i++) mpfr_init2 (x[i], precision);
	int nlt = 1001;
	mpfr_t lt[nlt]; 
		for (i=0; i<nlt; i++) {
			mpfr_init2 (lt[i], precision);
			mpfr_set_si (lt[i], i, GMP_RNDN);
			mpfr_div_si (lt[i], lt[i], 2, GMP_RNDN);
		}
	mpfr_t tol; mpfr_init2 (tol, precision);
		mpfr_set_str (tol, "1e-30", 10, GMP_RNDN);

/*	ORBITA ESTABLE */
/*	mpfr_set_str (x[0], "0.", 10, GMP_RNDN);
	mpfr_set_str (x[1], "0.2", 10, GMP_RNDN);
	mpfr_set_str (x[2], "0.46404022814119610909401263386808", 10, GMP_RNDN);
	mpfr_set_str (x[3], "0.", 10, GMP_RNDN);
*/

/*	ORBITA CAOTICA */
	mpfr_set_str (x[0], "0.", 10, GMP_RNDN);
	mpfr_set_str (x[1], "-0.2", 10, GMP_RNDN);
	mpfr_set_str (x[2], "0.45240100206196124943908443226062", 10, GMP_RNDN);
	mpfr_set_str (x[3], "0.", 10, GMP_RNDN);


	FILE *fout = fopen ("MPorbitShort.txt", "w");

	mp_taylor_old (nvar, x, nlt, lt, tol, fout);

//void mp_taylor (int nvar, mpfr_t x[nvar], mpfr_t t0, mpfr_t delta, int nt, 
//		mpfr_t tol, FILE *fout)

	fclose (fout);
	
	return 1;
}

