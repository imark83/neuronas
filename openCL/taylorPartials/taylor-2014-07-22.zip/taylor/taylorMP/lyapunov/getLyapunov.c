#include <stdio.h>
#include <mpfr.h>
#include <math.h>

int digits = 50;

double getLogNorm (mpfr_t x[4]);

int main () {
	mpfr_t t, trash, x[4];
	int i, j;
	int precision = (int) ceil (digits * 3.321928);
	double mle, y0;

	mpfr_init2 (t, precision);
	mpfr_init2 (trash, precision);
	for (i=0; i<4; i++) mpfr_init2 (x[i], precision);

	FILE *finp = fopen ("MPlyapunov.txt", "r");
	FILE *fout = fopen ("MPMLE.txt", "w");

	mpfr_inp_str (t, finp, 10, GMP_RNDN);
	for (i=0; i<4; i++) mpfr_inp_str (trash, finp, 10, GMP_RNDN);
	for (i=0; i<4; i++) mpfr_inp_str (x[i], finp, 10, GMP_RNDN);
	fscanf (finp, "\n");	
	y0 = getLogNorm (x);

	for (j=1; j<999; j++) {
		mpfr_inp_str (t, finp, 10, GMP_RNDN);
		for (i=0; i<4; i++) mpfr_inp_str (trash, finp, 10, GMP_RNDN);
		for (i=0; i<4; i++) mpfr_inp_str (x[i], finp, 10, GMP_RNDN);
		fscanf (finp, "\n");	

		mle = (getLogNorm (x) - y0)/mpfr_get_d (t, GMP_RNDN);
		fprintf (fout, "%.16le   %.16le\n", 
			mpfr_get_d (t, GMP_RNDN), mle);

	}

	fclose (finp); fclose (fout);
	return 1;
}



double getLogNorm (mpfr_t x[4]) {
	int precision = (int) ceil (digits * 3.321928);
	mpfr_t mpRes; mpfr_init2 (mpRes, precision);
		mpfr_set_si (mpRes, 0, GMP_RNDN);
	mpfr_t aux; mpfr_init2 (aux, precision);
	int i;

	for (i=0; i<=4; i++) {
		mpfr_mul (aux, x[0], x[0], GMP_RNDN);
		mpfr_add (mpRes, mpRes, aux, GMP_RNDN);
	}
	mpfr_sqrt (mpRes, mpRes, GMP_RNDN);
	mpfr_log (mpRes, mpRes, GMP_RNDN);

	return mpfr_get_d (mpRes, GMP_RNDN);
}
