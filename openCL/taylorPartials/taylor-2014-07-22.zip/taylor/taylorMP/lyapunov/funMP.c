#include "funMP.h"

mpfr_t s, r, b;

void mp_fun (int nvar, int order, mpfr_t t, mpfr_t x[nvar], 
		mpfr_t series[nvar][order+1]) {
	int i, j;
	extern int digits;
	int precision = (int) ceil (digits * 3.321928);




	for (i=0; i<nvar; i++) mpfr_set (series[i][0], x[i], GMP_RNDN);

	int nlink = 18;
	mpfr_t l[nlink][order];
	for (i=0; i<nlink; i++) for (j=0; j<order; j++) 
		mpfr_init2 (l[i][j], precision);

	for (i=0; i<order; i++) {
		mp_mulAD (i, l[0], series[0], series[0]);
		mp_mulAD (i, l[1], series[1], series[1]);
		mp_mulAD (i, l[2], series[0], series[1]);
			mpfr_mul_si (l[3][i], l[2][i], 2, GMP_RNDN);
		mp_sumAD (i, l[4], series[0], l[3]);
			mpfr_mul_si (l[5][i], l[4][i], -1, GMP_RNDN);
		mp_subAD (i, l[6], l[1], l[0]);
		mp_subAD (i, l[7], l[6], series[1]);

		mp_mulAD (i, l[8], series[1], series[4]);
		mp_mulAD (i, l[9], series[0], series[5]);
		mp_mulAD (i, l[10], series[0], series[4]);
		mp_mulAD (i, l[11], series[1], series[5]);
		mp_sumAD (i, l[12], l[8], l[9]);
			mpfr_mul_si (l[13][i], l[12][i], -2, GMP_RNDN);
		mp_subAD (i, l[14], l[13], series[4]);
		mp_subAD (i, l[15], l[11], l[10]);
			mpfr_mul_si (l[16][i], l[15][i], 2, GMP_RNDN);
		mp_subAD (i, l[17], l[16], series[5]);





		mpfr_div_si (series[0][i+1], series[2][i], i+1, GMP_RNDN);
		mpfr_div_si (series[1][i+1], series[3][i], i+1, GMP_RNDN);
		mpfr_div_si (series[2][i+1], l[5][i], i+1, GMP_RNDN);
		mpfr_div_si (series[3][i+1], l[7][i], i+1, GMP_RNDN);

		mpfr_div_si (series[4][i+1], series[6][i], i+1, GMP_RNDN);
		mpfr_div_si (series[5][i+1], series[7][i], i+1, GMP_RNDN);
		mpfr_div_si (series[6][i+1], l[14][i], i+1, GMP_RNDN);
		mpfr_div_si (series[7][i+1], l[17][i], i+1, GMP_RNDN);
	}

	for (i=0; i<nlink; i++) for (j=0; j<order; j++) mpfr_clear (l[i][j]);

}

void printFunctions (FILE *fout, mpfr_t x[], int digits) {
}



