#include "taylorMP.h"
int fac = 1;
int digits = 600;

int event = -1;
FILE *fpoinc = NULL;
int main () {
	int nvar = 3;
	int nlt = 1001;
	int i, precision = (int) ceil (digits * 3.321928);
	mpfr_t x[nvar]; for (i=0; i<nvar; i++) mpfr_init2 (x[i], precision);
	mpfr_t t0, tf, tol; 
	mpfr_init2 (tol, precision);
	
	mpfr_t lt[nlt]; for (i=0; i<nlt; i++) {
		mpfr_init2 (lt[i], precision);
		mpfr_set_si (lt[i], i, GMP_RNDN);
	}


	mpfr_set_str (x[0], "1.", 10, GMP_RNDN);
	mpfr_set_str (x[1], "0.", 10, GMP_RNDN);
	mpfr_set_str (x[2], "0.", 10, GMP_RNDN);
	mpfr_set_str (tol, "1e-605", 10, GMP_RNDN);

	FILE *fout = fopen ("lor600MP.txt","w");

	mp_taylor_old (nvar, x, nlt, lt, tol, fout);

	fclose (fout);
	return 0;

}

