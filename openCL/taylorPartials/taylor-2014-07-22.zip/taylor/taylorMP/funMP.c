#include "funMP.h"

mpfr_t s, b, r;
extern digits;

void mp_fun (int nvar, int order, mpfr_t t, mpfr_t x[nvar], 
		mpfr_t series[nvar][order+1]) {

	int i, j;
	static int unavez = 1, precision;
	if (unavez) {
		precision = (int) ceil (digits * 3.321928);
		mpfr_init2 (s, precision);
		mpfr_set_str (s, "10", 10, GMP_RNDN);
		mpfr_init2 (b, precision);
		mpfr_set_str (b, "8", 10, GMP_RNDN);
			mpfr_div_si (b, b, 3, GMP_RNDN);
		mpfr_init2 (r, precision);
		mpfr_set_str (r, "28", 10, GMP_RNDN);
	}
	unavez = 0;
	for (i=0; i<nvar; i++) mpfr_set (series[i][0], x[i], GMP_RNDN);

	int nl = 9;
	mpfr_t l[nl][order];
	for (i=0; i<nl; i++) for (j=0; j<order; j++) mpfr_init (l[i][j]);

	for (i=0; i<order; i++) {
		mp_subAD (i, l[0], series[1], series[0]);
			mpfr_mul (l[1][i], l[0][i], s, GMP_RNDN);
		mp_mulAD (i, l[2], series[0], series[2]);
			mpfr_mul (l[3][i], series[0][i], r, GMP_RNDN);
		mp_subAD (i, l[4], l[3], l[2]);
		mp_subAD (i, l[5], l[4], series[1]);
		mp_mulAD (i, l[6], series[0], series[1]);
			mpfr_mul (l[7][i], series[2][i], b, GMP_RNDN);
		mp_subAD (i, l[8], l[6], l[7]);


		mpfr_div_si (series[0][i+1], l[1][i], i+1, GMP_RNDN);
		mpfr_div_si (series[1][i+1], l[5][i], i+1, GMP_RNDN);
		mpfr_div_si (series[2][i+1], l[8][i], i+1, GMP_RNDN);
	}

	for (i=0; i<nl; i++) for (j=0; j<order; j++) mpfr_clear (l[i][j]);

}

void printFunctions (FILE *fout, mpfr_t x[], int digits) {
}



