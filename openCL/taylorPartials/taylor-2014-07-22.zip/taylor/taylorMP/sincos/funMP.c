#include "funMP.h"


void mp_fun (int nvar, int order, mpfr_t t, mpfr_t x[nvar], 
		mpfr_t series[nvar][order+1]) {

	int i;
	for (i=0; i<nvar; i++) mpfr_set (series[i][0], x[i], GMP_RNDN);

	for (i=0; i<order; i++) {
		mpfr_set (series[0][i+1], series[1][i], GMP_RNDN);
		mpfr_set (series[1][i+1], series[0][i], GMP_RNDN);
			mpfr_mul_si (series[1][i+1], series[1][i+1], -1, GMP_RNDN);
		mpfr_div_si (series[0][i+1], series[0][i+1], i+1, GMP_RNDN);
		mpfr_div_si (series[1][i+1], series[1][i+1], i+1, GMP_RNDN);
	}


}

void printFunctions (FILE *fout, mpfr_t x[]) {
	//fprintf (fout, "  %.16le  %.16le", getEnergy (x), getCasimir (x));
}

