#ifndef _fun_h
#define _fun_h
#include <stdio.h>
#include "taylorADMP.h"

void mp_fun (int nvar, int order, mpfr_t t, mpfr_t x[nvar], 
		mpfr_t series[nvar][order]);
void printFunctions (FILE *fout, mpfr_t x[]);


#endif
