clear;


o18 = load ('DPorbit18Short.txt');

oMP = load ('MPorbitShort.txt');


for i=1:1001
	o18(i,7) = (o18(i,2) - oMP(i,2))^2 + (o18(i,3) - oMP(i,3))^2 + (o18(i,4) - oMP(i,4))^2 + (o18(i,5) - oMP(i,5))^2;
	o18(i,7) = sqrt(o18(i,7));

end

loglog (o18(:,1), o18(:,7), '-b');
hold off;

