clear;


o14 = load ('DPorbit14.txt');
o16 = load ('DPorbit15.txt');
o18 = load ('DPorbit18.txt');



for i=1:1001
	o14(i,7) = abs(o14(i,6) - 0.125);
	o16(i,7) = abs(o16(i,6) - 0.125);
	o18(i,7) = abs(o18(i,6) - 0.125);

end

loglog (o14(:,1), o14(:,7), '-g');
hold on;
loglog (o16(:,1), o16(:,7), '-r');
loglog (o18(:,1), o18(:,7), '-b');
hold off;

