#include "taylor.h"

int kahan = 1;
int fac = 1;
int event = -1;
FILE *fpoinc;
int main () {
	int nvar = 4;

	double x[nvar];
	double t0 = 0.;
	double tf = 10000000;
	int nt = 1000;
	double tol = 1e-15;
	x[0] = 0.;
	x[1] = -0.2;
	x[2] = 0.45240100206196124;
	x[3] = 0.;

	fpoinc = stdout;


	FILE *fout = fopen ("DPorbit15.txt", "w");

	taylor (nvar, x, t0, tf/nt, nt, tol, fout);

	fclose (fout);
	
	return 1;
}

