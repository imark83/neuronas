clear;


o14 = load ('DPorbit14.txt');
o16 = load ('DPorbit16.txt');
o18 = load ('DPorbit18.txt');

oMP = load ('MPorbit.txt');


for i=1:1001
	o14(i,7) = (o14(i,2) - oMP(i,2))^2 + (o14(i,3) - oMP(i,3))^2 + (o14(i,4) - oMP(i,4))^2 + (o14(i,5) - oMP(i,5))^2;
	o14(i,7) = sqrt(o14(i,7));

	o16(i,7) = (o16(i,2) - oMP(i,2))^2 + (o16(i,3) - oMP(i,3))^2 + (o16(i,4) - oMP(i,4))^2 + (o16(i,5) - oMP(i,5))^2;
	o16(i,7) = sqrt(o16(i,7));

	o18(i,7) = (o18(i,2) - oMP(i,2))^2 + (o18(i,3) - oMP(i,3))^2 + (o18(i,4) - oMP(i,4))^2 + (o18(i,5) - oMP(i,5))^2;
	o18(i,7) = sqrt(o18(i,7));

end

loglog (o14(:,1), o14(:,7), '-g');
hold on;
loglog (o16(:,1), o16(:,7), '-r');
loglog (o18(:,1), o18(:,7), '-b');
hold off;

