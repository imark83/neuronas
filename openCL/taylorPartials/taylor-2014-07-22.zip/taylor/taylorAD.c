#include "taylorAD.h"


void dp_sumAD (int order, double *rop, double *op1, 
		double *op2) {
	rop[order] = op1[order] + op2[order];
}

void dp_smCAD (int order, double *rop, double *op1, 
		double op2) {
	if (order == 0) {
		rop[order] = op1[order] + op2;
	} else rop[order] = op1[order];
}

void dp_subAD (int order, double *rop, double *op1, 
		double *op2) {
	rop[order] = op1[order] - op2[order];
}

void dp_mulAD (int order, double *rop, double *op1, 
		double *op2) {
	int i;
	rop[order] = 0.;
	for (i=0; i<=order; i++) rop[order] += op1[i] * op2[order-i];
}

void dp_mlCAD (int order, double *rop, double *op1,
		double op2) {
	rop[order] = op2 * op1[order];
}

void dp_divAD (int order, double *rop, double *op1,
		double *op2) {
	if (op2[0] == 0.) {printf ("Error, divide by 0, bad result\n"); return;}

	int i;
	rop[order] = 0.;
	for (i=1; i<=order; i++) rop[order] += op2[i] * rop[order-i];
	rop[order] = (op1[order] - rop[order]) / op2[0];
}

void dp_invAD (int order, double *rop, double *op,
		double cte) {
	if (op[0] == 0.0) {printf ("Error, divide by 0, bad result\n"); return;}
	int i;
	if (order == 0) rop[0] = cte / op[0];
	else {
		rop[order] = 0.0;
		for (i=1; i<=order; i++)
			rop[order] -= op[i] * rop[order-i];
		rop[order] /= op[0];
	}
}

void dp_powAD (int order, double *rop, double *op1,
		double op2) {
	if (op1[0] == 0.) {printf ("Error, divide by 0, bad result\n"); return;}
	if (order == 0) rop [0] = pow (op1[0], op2);
	else {
		int i;
		rop[order] = 0.;
		for (i=0; i<order; i++) 
			rop[order] += (order*op2 - i*(op2+1)) * 
				op1[order-i] * rop[i];
		rop[order] = rop[order] / op1[0] / order;


	}
}

void dp_expAD (int order, double *rop, double *op) { 
	int i; 
	if (order == 0) 
		rop[0] = exp(op[0]); 
	else { 
		rop[order] = order *rop[0]*op[order]; 
		for(i = 1; i < order; i++) 
			rop[order] += (order-i) * rop[i] * op[order-i];
		rop[order] /= order; 
	} 
} 



void dp_logAD (int order, double *rop, double *op) {
	int i; 

	if (order == 0) { 
		if(op[0] == 0.0) { 
			printf ("*** Function log found division by zero ***\n");
			return;
		} 
		rop[0] = log (op[0]); 
	} else { 
		rop[order] = order * op[order]; 
		for (i = 1; i<order; i++) 
			rop[order] -= (order - i) * op[i] * rop[order-i]; 
		rop[order] /= order * op[0]; 
	} 
} 

void dp_sinAD (int order, double *rop, double *op, double *cosSeries) {
	int i; 
	if (order == 0) { 
		rop[0] = sin (op[0]); 
	} else { 
		rop[order] = op[1] * cosSeries[order-1];  
		for (i = 2; i <= order; i++) 
			rop[order] += i * op[i] * cosSeries[order-i]; 
		rop[order] /= order; 
	} 
} 

void dp_cosAD (int order, double *rop, double *op, double *sinSeries) {
	int i;
	if(order == 0) { 
		rop[0] = cos (op[0]); 
	} else { 
		rop[order] = -op[1] * sinSeries[order-1]; 
		for (i = 2; i <= order; i++) 
			rop[order] -= i * op [i] * sinSeries[order-i]; 
		rop[order] /= order;   
	}     
} 



