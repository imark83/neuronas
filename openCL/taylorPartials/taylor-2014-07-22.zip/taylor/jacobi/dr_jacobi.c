#include "taylor.h"

int kahan = 1;
int fac = 300;
int main () {
	int nvar = 3;

	double x[3];
	double t0 = 0.;
	double tf = 100000.;
	double tol = 1e-18;

	x[0] = 0.;
	x[1] = 1.;
	x[2] = 1.;

	FILE *fout = fopen ("jacobi2.txt", "w");

	taylor (nvar, x, t0, tf, tol, fout);

	fclose (fout);
	
	return 1;
}

