#include "fun.h"

double k2 = 0.25;

void fun (int nvar, int order, double t, double x[nvar], 
		double series[nvar][order+1]) {

	int i;
	
	for (i=0; i<nvar; i++) series[i][0] = x[i];
	double l[3][order+1];

	for (i=0; i<order; i++) {
		dp_mulAD (i, l[0], series[1], series[2]);
		dp_mulAD (i, l[1], series[0], series[2]);
			l[1][i] *= -1.;
		dp_mulAD (i, l[2], series[0], series[1]);
			l[2][i] *= -k2;


		series[0][i+1] = l[0][i]/(i+1);
		series[1][i+1] = l[1][i]/(i+1);
		series[2][i+1] = l[2][i]/(i+1); 
	}


}

void printFunctions (FILE *fout, double x[]) {
	fprintf (fout, "  %.16le  %.16le", getSinCos (x), getSinDen (x));
}

double getSinCos(double x[]) {
	return x[0]*x[0] + x[1]*x[1];

}

double getSinDen (double x[]) {
	return k2*x[0]*x[0] + x[2]*x[2];
}
